package com.dao;
/***
*write by createfile 
*�û���Ϣ
*/
import com.util.*;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
public class UsersDao {
	public UsersDao(){
	
	}
	public int addUsers(HttpServletRequest req){
		String username=req.getParameter("username")==null?"":req.getParameter("username");
		String password=req.getParameter("password")==null?"":req.getParameter("password");
		String usertype=req.getParameter("usertype")==null?"":req.getParameter("usertype");
		String dept=req.getParameter("dept")==null?"":req.getParameter("dept");
		String tel=req.getParameter("tel")==null?"":req.getParameter("tel");
		String qq=req.getParameter("qq")==null?"":req.getParameter("qq");
		String img=req.getParameter("img")==null?"":req.getParameter("img");
		String address=req.getParameter("address")==null?"":req.getParameter("address");
		String userid=req.getParameter("userid")==null?"":req.getParameter("userid");
		String sql ="insert into USERS("+
        		"USERNAME"+
        		",PASSWORD"+
        		",USERTYPE"+
        		",DEPT"+
        		",TEL"+
        		",QQ"+
        		",IMG"+
        		",ADDRESS"+
        		",userid"+
        	") values("+
        		"'"+username+"'"+
        	        		",'"+password+"'"+
        	        		",'"+usertype+"'"+
        	        		",'"+dept+"'"+
        	        		",'"+tel+"'"+
        	        		",'"+qq+"'"+
        	        		",'"+img+"'"+
        	        		",'"+address+"'"+
        	        		",'"+userid+"'"+
        	")";
        	DB db = new DB();
        	return db.executeSql(sql);	
	}
	public int delUsers(HttpServletRequest req){
         String userid=req.getParameter("userid");
		String sql ="delete from USERS where 1=1 "+
    		" and userid ='"+userid+"'"+
    	"";
    	DB db = new DB();
    	return db.executeSql(sql);	
	}
	public int updUsers(HttpServletRequest req){
		String username=req.getParameter("username")==null?"":req.getParameter("username");
		String password=req.getParameter("password")==null?"":req.getParameter("password");
		String usertype=req.getParameter("usertype")==null?"":req.getParameter("usertype");
		String dept=req.getParameter("dept")==null?"":req.getParameter("dept");
		String tel=req.getParameter("tel")==null?"":req.getParameter("tel");
		String qq=req.getParameter("qq")==null?"":req.getParameter("qq");
		String img=req.getParameter("img")==null?"":req.getParameter("img");
		String address=req.getParameter("address")==null?"":req.getParameter("address");
        String userid=req.getParameter("userid");
		String sql ="update USERS set "+
        		"USERNAME='"+username+"'"+
        		",PASSWORD='"+password+"'"+
        		",USERTYPE='"+usertype+"'"+
        		",DEPT='"+dept+"'"+
        		",TEL='"+tel+"'"+
        		",QQ='"+qq+"'"+
        		",IMG='"+img+"'"+
        		",ADDRESS='"+address+"'"+
        	" where 1=1 "+
    		" and userid ='"+userid+"'"+
    	"";
        	DB db = new DB();
        	return db.executeSql(sql);	
	}
	public Map<String,Object> findUsersById(HttpServletRequest req){
         String userid=req.getParameter("userid");
		String sql ="select u.*,f.filepath+'/'+f.newname path,f.filename,f.fileid,c.codename usertypename from USERS u left join files f on u.img=f.fileid left join codes c on c.id=u.usertype where 1=1 "+
    		" and userid ='"+userid+"'"+
    	"";
    	DB db = new DB();
    	Map<String,Object> map = null;
    	List<Map<String,Object>> list = db.query(sql);
    	if(list!=null&&list.size()>0){
    		map = list.get(0);
    	}
    	return map;	
	}
	
	
	public PageModel findUsersByCondition(HttpServletRequest req){
		String username=req.getParameter("username")==null?"":req.getParameter("username");
		req.setAttribute("username", username);
		String password=req.getParameter("password")==null?"":req.getParameter("password");
		req.setAttribute("password", password);
		String usertype=req.getParameter("usertype")==null?"":req.getParameter("usertype");
		req.setAttribute("usertype", usertype);
		String dept=req.getParameter("dept")==null?"":req.getParameter("dept");
		req.setAttribute("dept", dept);
		String tel=req.getParameter("tel")==null?"":req.getParameter("tel");
		req.setAttribute("tel", tel);
		String qq=req.getParameter("qq")==null?"":req.getParameter("qq");
		req.setAttribute("qq", qq);
		String img=req.getParameter("img")==null?"":req.getParameter("img");
		req.setAttribute("img", img);
		String address=req.getParameter("address")==null?"":req.getParameter("address");
		req.setAttribute("address", address);
         String userid=req.getParameter("userid");
		String sql ="";
		String where="";
		if(username!=null&&!"".equals(username)){
    		where+=" and u.USERNAME like '%"+username+"%'";
		}
		if(password!=null&&!"".equals(password)){
    		where+=" and u.PASSWORD like '%"+password+"%'";
		}
		if(usertype!=null&&!"".equals(usertype)){
    		where+=" and u.USERTYPE like '%"+usertype+"%'";
		}
		if(dept!=null&&!"".equals(dept)){
    		where+=" and u.DEPT like '%"+dept+"%'";
		}
		if(tel!=null&&!"".equals(tel)){
    		where+=" and u.TEL like '%"+tel+"%'";
		}
		if(qq!=null&&!"".equals(qq)){
    		where+=" and u.QQ like '%"+qq+"%'";
		}
		if(img!=null&&!"".equals(img)){
    		where+=" and u.IMG like '%"+img+"%'";
		}
		if(address!=null&&!"".equals(address)){
    		where+=" and u.ADDRESS like '%"+address+"%'";
		}
    	String countsql ="select count(*) from USERS u where 1=1 "+where;
    	PageModel model = new PageModel();
		String tempPage = req.getParameter("currentPage");
		int currentPage = 1;
		try {
			currentPage = Integer.parseInt(tempPage);
		} catch (NumberFormatException e) {
			currentPage=1;
		}
		model.setCurrentPage(currentPage);
		String tempCount = req.getParameter("pageCount");
		int pageCount = 20;
		try {
			pageCount = Integer.parseInt(tempCount);
		} catch (NumberFormatException e) {
			pageCount=20;
		}
		model.setPageCount(pageCount);
		if("sqlserver".equals(DB.SQLTYPE)){
			if(currentPage==1){
				sql="select top "+pageCount+" u.userid,u.username,u.password,c.codename usertypename,u.dept,u.tel,u.qq,u.img,u.address,u.usertype from USERS u left join codes c on id=usertype where 1=1 "+where+" order by  userid  desc";
			}else{
				sql="select top "+pageCount+" u.userid,u.username,u.password,c.codename usertypename,u.usertype,u.dept,u.tel,u.qq,u.img,u.address from USERS u left join codes c on id=usertype where 1=1 "+where+" and   userid  " +
					"not in (select top (("+currentPage+"-1)*"+pageCount+")  userid  from USERS u where 1=1 "+where+"  order by  userid  desc) order by  userid  desc";
			}
		}
    	DB db = new DB();
    	int count = Integer.parseInt(db.queryFirst(countsql));
    	model.setTotalCount(count);
    	if(count>0){
    		model.setRes(db.query(sql));
    	}
    	return model;	
	}
	
}