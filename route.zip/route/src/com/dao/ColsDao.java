package com.dao;
/***
*��
*/
import com.util.*;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
public class ColsDao {
	public ColsDao(){
	
	}
	public int addCols(HttpServletRequest req){
		String colname=req.getParameter("colname")==null?"":req.getParameter("colname");
		String pk=req.getParameter("pk")==null?"":req.getParameter("pk");
		String fk=req.getParameter("fk")==null?"":req.getParameter("fk");
		String datatype=req.getParameter("datatype")==null?"":req.getParameter("datatype");
		String showtype=req.getParameter("showtype")==null?"":req.getParameter("showtype");
		String isreadonly=req.getParameter("isreadonly")==null?"":req.getParameter("isreadonly");
		String checktype=req.getParameter("checktype")==null?"":req.getParameter("checktype");
		String sqlid=req.getParameter("sqlid")==null?"":req.getParameter("sqlid");
		String style=req.getParameter("style")==null?"":req.getParameter("style");
		String event=req.getParameter("event")==null?"":req.getParameter("event");
		String other=req.getParameter("other")==null?"":req.getParameter("other");
		String changeid=req.getParameter("changeid")==null?"":req.getParameter("changeid");
		String changesqlid=req.getParameter("changesqlid")==null?"":req.getParameter("changesqlid");
		String num=req.getParameter("num")==null?"":req.getParameter("num");
		String sql ="insert into COLS("+
        		"COLNAME"+
        		",PK"+
        		",FK"+
        		",DATATYPE"+
        		",SHOWTYPE"+
        		",ISREADONLY"+
        		",CHECKTYPE"+
        		",SQLID"+
        		",STYLE"+
        		",EVENT"+
        		",OTHER"+
        		",CHANGEID"+
        		",CHANGESQLID"+
        		",NUM"+
        	") values("+
        		"'"+colname+"'"+
        	        		",'"+pk+"'"+
        	        		",'"+fk+"'"+
        	        		",'"+datatype+"'"+
        	        		",'"+showtype+"'"+
        	        		",'"+isreadonly+"'"+
        	        		",'"+checktype+"'"+
        	        		",'"+sqlid+"'"+
        	        		",'"+style+"'"+
        	        		",'"+event+"'"+
        	        		",'"+other+"'"+
        	        		",'"+changeid+"'"+
        	        		",'"+changesqlid+"'"+
        	        		",'"+num+"'"+
        	")";
        	DB db = new DB();
        	return db.executeSql(sql);	
	}
	public int delCols(HttpServletRequest req){
         String col=req.getParameter("col");
         String tablename=req.getParameter("tablename");
		String sql ="delete from COLS where 1=1 "+
    		" and col ='"+col+"'"+
    		" and tablename ='"+tablename+"'"+
    	"";
    	DB db = new DB();
    	return db.executeSql(sql);	
	}
	public int updCols(HttpServletRequest req){
		String colname=req.getParameter("colname")==null?"":req.getParameter("colname");
		String pk=req.getParameter("pk")==null?"":req.getParameter("pk");
		String fk=req.getParameter("fk")==null?"":req.getParameter("fk");
		String datatype=req.getParameter("datatype")==null?"":req.getParameter("datatype");
		String showtype=req.getParameter("showtype")==null?"":req.getParameter("showtype");
		String isreadonly=req.getParameter("isreadonly")==null?"":req.getParameter("isreadonly");
		String checktype=req.getParameter("checktype")==null?"":req.getParameter("checktype");
		String sqlid=req.getParameter("sqlid")==null?"":req.getParameter("sqlid");
		String style=req.getParameter("style")==null?"":req.getParameter("style");
		String event=req.getParameter("event")==null?"":req.getParameter("event");
		String other=req.getParameter("other")==null?"":req.getParameter("other");
		String changeid=req.getParameter("changeid")==null?"":req.getParameter("changeid");
		String changesqlid=req.getParameter("changesqlid")==null?"":req.getParameter("changesqlid");
		String num=req.getParameter("num")==null?"":req.getParameter("num");
        String col=req.getParameter("col");
        String tablename=req.getParameter("tablename");
		String sql ="update COLS set "+
        		"COLNAME='"+colname+"'"+
        		",PK='"+pk+"'"+
        		",FK='"+fk+"'"+
        		",DATATYPE='"+datatype+"'"+
        		",SHOWTYPE='"+showtype+"'"+
        		",ISREADONLY='"+isreadonly+"'"+
        		",CHECKTYPE='"+checktype+"'"+
        		",SQLID='"+sqlid+"'"+
        		",STYLE='"+style+"'"+
        		",EVENT='"+event+"'"+
        		",OTHER='"+other+"'"+
        		",CHANGEID='"+changeid+"'"+
        		",CHANGESQLID='"+changesqlid+"'"+
        		",NUM='"+num+"'"+
        	" where 1=1 "+
    		" and col ='"+col+"'"+
    		" and tablename ='"+tablename+"'"+
    	"";
        	DB db = new DB();
        	return db.executeSql(sql);	
	}
	public Map<String,Object> findColsById(HttpServletRequest req){
         String col=req.getParameter("col");
         String tablename=req.getParameter("tablename");
		String sql ="select * from COLS where 1=1 "+
    		" and col ='"+col+"'"+
    		" and tablename ='"+tablename+"'"+
    	"";
    	DB db = new DB();
    	Map<String,Object> map = null;
    	List<Map<String,Object>> list = db.query(sql);
    	if(list!=null&&list.size()>0){
    		map = list.get(0);
    	}
    	return map;	
	}
	
	
	public PageModel findColsByCondition(HttpServletRequest req){
		String colname=req.getParameter("colname")==null?"":req.getParameter("colname");
		req.setAttribute("colname", colname);
		String pk=req.getParameter("pk")==null?"":req.getParameter("pk");
		req.setAttribute("pk", pk);
		String fk=req.getParameter("fk")==null?"":req.getParameter("fk");
		req.setAttribute("fk", fk);
		String datatype=req.getParameter("datatype")==null?"":req.getParameter("datatype");
		req.setAttribute("datatype", datatype);
		String showtype=req.getParameter("showtype")==null?"":req.getParameter("showtype");
		req.setAttribute("showtype", showtype);
		String isreadonly=req.getParameter("isreadonly")==null?"":req.getParameter("isreadonly");
		req.setAttribute("isreadonly", isreadonly);
		String checktype=req.getParameter("checktype")==null?"":req.getParameter("checktype");
		req.setAttribute("checktype", checktype);
		String sqlid=req.getParameter("sqlid")==null?"":req.getParameter("sqlid");
		req.setAttribute("sqlid", sqlid);
		String style=req.getParameter("style")==null?"":req.getParameter("style");
		req.setAttribute("style", style);
		String event=req.getParameter("event")==null?"":req.getParameter("event");
		req.setAttribute("event", event);
		String other=req.getParameter("other")==null?"":req.getParameter("other");
		req.setAttribute("other", other);
		String changeid=req.getParameter("changeid")==null?"":req.getParameter("changeid");
		req.setAttribute("changeid", changeid);
		String changesqlid=req.getParameter("changesqlid")==null?"":req.getParameter("changesqlid");
		req.setAttribute("changesqlid", changesqlid);
		String num=req.getParameter("num")==null?"":req.getParameter("num");
		req.setAttribute("num", num);
         String col=req.getParameter("col");
         String tablename=req.getParameter("tablename");
		String sql ="";
		String where="";
		if(colname!=null&&!"".equals(colname)){
    		where+=" and COLNAME like '%"+colname+"%'";
		}
		if(pk!=null&&!"".equals(pk)){
    		where+=" and PK like '%"+pk+"%'";
		}
		if(fk!=null&&!"".equals(fk)){
    		where+=" and FK like '%"+fk+"%'";
		}
		if(datatype!=null&&!"".equals(datatype)){
    		where+=" and DATATYPE like '%"+datatype+"%'";
		}
		if(showtype!=null&&!"".equals(showtype)){
    		where+=" and SHOWTYPE like '%"+showtype+"%'";
		}
		if(isreadonly!=null&&!"".equals(isreadonly)){
    		where+=" and ISREADONLY like '%"+isreadonly+"%'";
		}
		if(checktype!=null&&!"".equals(checktype)){
    		where+=" and CHECKTYPE like '%"+checktype+"%'";
		}
		if(sqlid!=null&&!"".equals(sqlid)){
    		where+=" and SQLID like '%"+sqlid+"%'";
		}
		if(style!=null&&!"".equals(style)){
    		where+=" and STYLE like '%"+style+"%'";
		}
		if(event!=null&&!"".equals(event)){
    		where+=" and EVENT like '%"+event+"%'";
		}
		if(other!=null&&!"".equals(other)){
    		where+=" and OTHER like '%"+other+"%'";
		}
		if(changeid!=null&&!"".equals(changeid)){
    		where+=" and CHANGEID like '%"+changeid+"%'";
		}
		if(changesqlid!=null&&!"".equals(changesqlid)){
    		where+=" and CHANGESQLID like '%"+changesqlid+"%'";
		}
		if(num!=null&&!"".equals(num)){
    		where+=" and NUM like '%"+num+"%'";
		}
    	String countsql ="select count(*) from COLS where 1=1 "+where;
    	PageModel model = new PageModel();
		String tempPage = req.getParameter("currentPage");
		int currentPage = 1;
		try {
			currentPage = Integer.parseInt(tempPage);
		} catch (NumberFormatException e) {
			currentPage=1;
		}
		model.setCurrentPage(currentPage);
		String tempCount = req.getParameter("pageCount");
		int pageCount = 20;
		try {
			pageCount = Integer.parseInt(tempCount);
		} catch (NumberFormatException e) {
			pageCount=20;
		}
		model.setPageCount(pageCount);
		if("sqlserver".equals(DB.SQLTYPE)){
			if(currentPage==1){
				sql="select top "+pageCount+" * from COLS where 1=1 "+where+" order by  col  tablename  desc";
			}else{
				sql="select top "+pageCount+" * from COLS where 1=1 "+where+" and   col  tablename  " +
					"not in (select top (("+currentPage+"-1)*"+pageCount+")  col  tablename  from COLS where 1=1 "+where+" order by  col  tablename  desc) order by  col  tablename  desc";
			}
		}
    	DB db = new DB();
    	int count = Integer.parseInt(db.queryFirst(countsql));
    	model.setTotalCount(count);
    	if(count>0){
    		model.setRes(db.query(sql));
    	}
    	return model;	
	}
	
}