package com.dao;
/***
*����
*/
import com.util.*;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
public class SheetDao {
	public SheetDao(){
	
	}
	public int addSheet(HttpServletRequest req){
		String reuserid=req.getParameter("reuserid")==null?"":req.getParameter("reuserid");
		String price=req.getParameter("price")==null?"":req.getParameter("price");
		String sheetuserid=req.getParameter("sheetuserid")==null?"":req.getParameter("sheetuserid");
		String address=req.getParameter("address")==null?"":req.getParameter("address");
		String weight=req.getParameter("weight")==null?"":req.getParameter("weight");
		String m=req.getParameter("m")==null?"":req.getParameter("m");
		String lastretel=req.getParameter("lastretel")==null?"":req.getParameter("lastretel");
		String state=req.getParameter("state")==null?"":req.getParameter("state");
		String name=req.getParameter("name")==null?"":req.getParameter("name");
		String lastreuserid=req.getParameter("lastreuserid")==null?"":req.getParameter("lastreuserid");
		String sql ="insert into TBL_SHEET("+
        		"RETIME"+
        		",REUSERID"+
        		",PRICE"+
        		",LASTRETIME"+
        		",DATETIMES"+
        		",SHEETUSERID"+
        		",ADDRESS"+
        		",WEIGHT"+
        		",M"+
        		",LASTRETEL"+
        		",STATE"+
        		",NAME"+
        		",SHEETTIME"+
        		",LASTREUSERID"+
        	") values("+
        		"null"+
        	        		",'"+reuserid+"'"+
        	        		",'"+price+"'"+
        	        		",null"+
        	        		",null"+
        	        		",'"+sheetuserid+"'"+
        	        		",'"+address+"'"+
        	        		",'"+weight+"'"+
        	        		",'"+m+"'"+
        	        		",'"+lastretel+"'"+
        	        		",'"+state+"'"+
        	        		",'"+name+"'"+
        	        		",getdate()"+
        	        		",'"+lastreuserid+"'"+
        	")";
        	DB db = new DB();
        	return db.executeSql(sql);	
	}
	public int delSheet(HttpServletRequest req){
         String id=req.getParameter("id");
		String sql ="delete from TBL_SHEET where 1=1 "+
    		" and id ='"+id+"'"+
    	"";
    	DB db = new DB();
    	return db.executeSql(sql);	
	}
	public int updSheet(HttpServletRequest req){
		String state=req.getParameter("state")==null?"":req.getParameter("state");
		state=Util.ISOtoGb2312(state);
        String id=req.getParameter("id");
        String userid=req.getParameter("userid");
        String col="";
        if("���տͻ�����".equals(state)){
        	col=",REUSERID='"+userid+"',RETIME=getdate()";
        }
        if("�ͻ��ջ�".equals(state)){
        	col=",LASTRETIME=getdate()";
        }
		String sql ="update TBL_SHEET set "+
        		"DATETIMES=getdate(),STATE='"+state+"'"+col+
        	" where 1=1 "+
    		" and id ='"+id+"'"+
    	"";
        	DB db = new DB();
        	return db.executeSql(sql);	
	}
	public Map<String,Object> findSheetById(HttpServletRequest req){
         String id=req.getParameter("id");
		String sql ="select * from TBL_SHEET where 1=1 "+
    		" and id ='"+id+"'"+
    	"";
    	DB db = new DB();
    	Map<String,Object> map = null;
    	List<Map<String,Object>> list = db.query(sql);
    	if(list!=null&&list.size()>0){
    		map = list.get(0);
    	}
    	return map;	
	}
	
	
	public PageModel findSheetByCondition(HttpServletRequest req){
		String retime=req.getParameter("retime")==null?"":req.getParameter("retime");
		req.setAttribute("retime", retime);
		String reuserid=req.getParameter("reuserid")==null?"":req.getParameter("reuserid");
		req.setAttribute("reuserid", reuserid);
		String price=req.getParameter("price")==null?"":req.getParameter("price");
		req.setAttribute("price", price);
		String lastretime=req.getParameter("lastretime")==null?"":req.getParameter("lastretime");
		req.setAttribute("lastretime", lastretime);
		String datetimes=req.getParameter("datetimes")==null?"":req.getParameter("datetimes");
		req.setAttribute("datetimes", datetimes);
		String sheetuserid=req.getParameter("sheetuserid")==null?"":req.getParameter("sheetuserid");
		req.setAttribute("sheetuserid", sheetuserid);
		String address=req.getParameter("address")==null?"":req.getParameter("address");
		req.setAttribute("address", address);
		String weight=req.getParameter("weight")==null?"":req.getParameter("weight");
		req.setAttribute("weight", weight);
		String m=req.getParameter("m")==null?"":req.getParameter("m");
		req.setAttribute("m", m);
		String lastretel=req.getParameter("lastretel")==null?"":req.getParameter("lastretel");
		req.setAttribute("lastretel", lastretel);
		String state=req.getParameter("state")==null?"":req.getParameter("state");
		req.setAttribute("state", state);
		String name=req.getParameter("name")==null?"":req.getParameter("name");
		req.setAttribute("name", name);
		String sheettime=req.getParameter("sheettime")==null?"":req.getParameter("sheettime");
		req.setAttribute("sheettime", sheettime);
		String lastreuserid=req.getParameter("lastreuserid")==null?"":req.getParameter("lastreuserid");
		req.setAttribute("lastreuserid", lastreuserid);
         String id=req.getParameter("id");
		String sql ="";
		String where="";
		if(retime!=null&&!"".equals(retime)){
    		where+=" and RETIME like '%"+retime+"%'";
		}
		if(reuserid!=null&&!"".equals(reuserid)){
    		where+=" and REUSERID like '%"+reuserid+"%'";
		}
		if(price!=null&&!"".equals(price)){
    		where+=" and PRICE like '%"+price+"%'";
		}
		if(lastretime!=null&&!"".equals(lastretime)){
    		where+=" and LASTRETIME like '%"+lastretime+"%'";
		}
		if(datetimes!=null&&!"".equals(datetimes)){
    		where+=" and DATETIMES like '%"+datetimes+"%'";
		}
		if(sheetuserid!=null&&!"".equals(sheetuserid)){
    		where+=" and SHEETUSERID like '%"+sheetuserid+"%'";
		}
		if(address!=null&&!"".equals(address)){
    		where+=" and ADDRESS like '%"+address+"%'";
		}
		if(weight!=null&&!"".equals(weight)){
    		where+=" and WEIGHT like '%"+weight+"%'";
		}
		if(m!=null&&!"".equals(m)){
    		where+=" and M like '%"+m+"%'";
		}
		if(lastretel!=null&&!"".equals(lastretel)){
    		where+=" and LASTRETEL like '%"+lastretel+"%'";
		}
		if(state!=null&&!"".equals(state)){
    		where+=" and STATE like '%"+state+"%'";
		}
		if(name!=null&&!"".equals(name)){
    		where+=" and NAME like '%"+name+"%'";
		}
		if(sheettime!=null&&!"".equals(sheettime)){
    		where+=" and SHEETTIME like '%"+sheettime+"%'";
		}
		if(lastreuserid!=null&&!"".equals(lastreuserid)){
    		where+=" and LASTREUSERID like '%"+lastreuserid+"%'";
		}
    	String countsql ="select count(*) from TBL_SHEET where 1=1 "+where;
    	PageModel model = new PageModel();
		String tempPage = req.getParameter("currentPage");
		int currentPage = 1;
		try {
			currentPage = Integer.parseInt(tempPage);
		} catch (NumberFormatException e) {
			currentPage=1;
		}
		model.setCurrentPage(currentPage);
		String tempCount = req.getParameter("pageCount");
		int pageCount = 20;
		try {
			pageCount = Integer.parseInt(tempCount);
		} catch (NumberFormatException e) {
			pageCount=20;
		}
		model.setPageCount(pageCount);
		if("sqlserver".equals(DB.SQLTYPE)){
			if(currentPage==1){
				sql="select top "+pageCount+" * from TBL_SHEET where 1=1 "+where+" order by  id  desc";
			}else{
				sql="select top "+pageCount+" * from TBL_SHEET where 1=1 "+where+" and   id  " +
					"not in (select top (("+currentPage+"-1)*"+pageCount+")  id  from TBL_SHEET where 1=1 "+where+" order by  id  desc) order by  id  desc";
			}
		}
    	DB db = new DB();
    	int count = Integer.parseInt(db.queryFirst(countsql));
    	model.setTotalCount(count);
    	if(count>0){
    		model.setRes(db.query(sql));
    	}
    	return model;	
	}
	
}