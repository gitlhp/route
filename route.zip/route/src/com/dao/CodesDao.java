package com.dao;
/***
*write by createfile 
*�����
*/
import com.util.*;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
public class CodesDao {
	public CodesDao(){
	
	}
	public int addCodes(HttpServletRequest req){
		String codetype=req.getParameter("codetype")==null?"":req.getParameter("codetype");
		String codename=req.getParameter("codename")==null?"":req.getParameter("codename");
		String ordernum=req.getParameter("ordernum")==null?"":req.getParameter("ordernum");
		String codetypename=req.getParameter("codetypename")==null?"":req.getParameter("codetypename");
		String sql ="insert into CODES("+
        		"CODETYPE"+
        		",CODENAME"+
        		",ORDERNUM"+
        		",codetypename"+
        	") values("+
        		"'"+codetype+"'"+
        	        		",'"+codename+"'"+
        	        		",'"+ordernum+"'"+
        	        		",'"+codetypename+"'"+
        	")";
        	DB db = new DB();
        	return db.executeSql(sql);	
	}
	public int delCodes(HttpServletRequest req){
         String id=req.getParameter("id");
		String sql ="delete from CODES where 1=1 "+
    		" and id ='"+id+"'"+
    	"";
    	DB db = new DB();
    	return db.executeSql(sql);	
	}
	public int updCodes(HttpServletRequest req){
		String codetype=req.getParameter("codetype")==null?"":req.getParameter("codetype");
		String codename=req.getParameter("codename")==null?"":req.getParameter("codename");
		String ordernum=req.getParameter("ordernum")==null?"":req.getParameter("ordernum");
		String codetypename=req.getParameter("codetypename")==null?"":req.getParameter("codetypename");
        String id=req.getParameter("id");
		String sql ="update CODES set "+
        		"CODETYPE='"+codetype+"'"+
        		",CODENAME='"+codename+"'"+
        		",ORDERNUM='"+ordernum+"'"+
        		",codetypename='"+codetypename+"'"+
        	" where 1=1 "+
    		" and id ='"+id+"'"+
    	"";
        	DB db = new DB();
        	return db.executeSql(sql);	
	}
	public Map<String,Object> findCodesById(HttpServletRequest req){
         String id=req.getParameter("id");
		String sql ="select * from CODES where 1=1 "+
    		" and id ='"+id+"'"+
    	"";
    	DB db = new DB();
    	Map<String,Object> map = null;
    	List<Map<String,Object>> list = db.query(sql);
    	if(list!=null&&list.size()>0){
    		map = list.get(0);
    	}
    	return map;	
	}
	
	
	public PageModel findCodesByCondition(HttpServletRequest req){
		String codetype=req.getParameter("codetype")==null?"":req.getParameter("codetype");
		req.setAttribute("codetype", codetype);
		String codename=req.getParameter("codename")==null?"":req.getParameter("codename");
		req.setAttribute("codename", codename);
		String ordernum=req.getParameter("ordernum")==null?"":req.getParameter("ordernum");
		req.setAttribute("ordernum", ordernum);
		String pid=req.getParameter("pid")==null?"":req.getParameter("pid");
		req.setAttribute("pid", pid);
         String id=req.getParameter("id");
		String sql ="";
		String where="";
		if(codetype!=null&&!"".equals(codetype)){
    		where+=" and CODETYPE like '%"+codetype+"%'";
		}
		if(codename!=null&&!"".equals(codename)){
    		where+=" and CODENAME like '%"+codename+"%'";
		}
		if(ordernum!=null&&!"".equals(ordernum)){
    		where+=" and ORDERNUM like '%"+ordernum+"%'";
		}
		if(pid!=null&&!"".equals(pid)){
    		where+=" and PID like '%"+pid+"%'";
		}
    	String countsql ="select count(*) from CODES where 1=1 "+where;
    	PageModel model = new PageModel();
		String tempPage = req.getParameter("currentPage");
		int currentPage = 1;
		try {
			currentPage = Integer.parseInt(tempPage);
		} catch (NumberFormatException e) {
			currentPage=1;
		}
		model.setCurrentPage(currentPage);
		String tempCount = req.getParameter("pageCount");
		int pageCount = 20;
		try {
			pageCount = Integer.parseInt(tempCount);
		} catch (NumberFormatException e) {
			pageCount=20;
		}
		model.setPageCount(pageCount);
		if("sqlserver".equals(DB.SQLTYPE)){
			if(currentPage==1){
				sql="select top "+pageCount+" * from CODES where 1=1 "+where+" order by  id  desc";
			}else{
				sql="select top "+pageCount+" * from CODES where 1=1 "+where+" and   id  " +
					"not in (select top (("+currentPage+"-1)*"+pageCount+")  id  from CODES  where 1=1 "+where+"  order by  id  desc) order by  id  desc";
			}
		}
    	DB db = new DB();
    	int count = Integer.parseInt(db.queryFirst(countsql));
    	model.setTotalCount(count);
    	if(count>0){
    		model.setRes(db.query(sql));
    	}
    	return model;	
	}
	
}