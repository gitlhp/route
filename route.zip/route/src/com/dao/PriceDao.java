package com.dao;
/***
*���ͼ۸�
*/
import com.util.*;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
public class PriceDao {
	public PriceDao(){
	
	}
	public int addPrice(HttpServletRequest req){
		String rid=req.getParameter("rid")==null?"":req.getParameter("rid");
		String w=req.getParameter("w")==null?"":req.getParameter("w");
		String pid=req.getParameter("pid")==null?"":req.getParameter("pid");
		String types=req.getParameter("types")==null?"":req.getParameter("types");
		String m1=req.getParameter("m1")==null?"":req.getParameter("m1");
		String m=req.getParameter("m")==null?"":req.getParameter("m");
		String w1=req.getParameter("w1")==null?"":req.getParameter("w1");
		String mem=req.getParameter("mem")==null?"":req.getParameter("mem");
		String sql ="insert into TBL_PRICE("+
        		"RID"+
        		",W"+
        		",PID"+
        		",TYPES"+
        		",M1"+
        		",M"+
        		",W1"+
        		",MEM"+
        	") values("+
        		"'"+rid+"'"+
        	        		",'"+w+"'"+
        	        		",'"+pid+"'"+
        	        		",'"+types+"'"+
        	        		",'"+m1+"'"+
        	        		",'"+m+"'"+
        	        		",'"+w1+"'"+
        	        		",'"+mem+"'"+
        	")";
        	DB db = new DB();
        	return db.executeSql(sql);	
	}
	public int delPrice(HttpServletRequest req){
         String id=req.getParameter("id");
		String sql ="delete from TBL_PRICE where 1=1 "+
    		" and id ='"+id+"'"+
    	"";
    	DB db = new DB();
    	return db.executeSql(sql);	
	}
	public int updPrice(HttpServletRequest req){
		String rid=req.getParameter("rid")==null?"":req.getParameter("rid");
		String w=req.getParameter("w")==null?"":req.getParameter("w");
		String pid=req.getParameter("pid")==null?"":req.getParameter("pid");
		String types=req.getParameter("types")==null?"":req.getParameter("types");
		String m1=req.getParameter("m1")==null?"":req.getParameter("m1");
		String m=req.getParameter("m")==null?"":req.getParameter("m");
		String w1=req.getParameter("w1")==null?"":req.getParameter("w1");
		String mem=req.getParameter("mem")==null?"":req.getParameter("mem");
        String id=req.getParameter("id");
		String sql ="update TBL_PRICE set "+
        		"RID='"+rid+"'"+
        		",W='"+w+"'"+
        		",PID='"+pid+"'"+
        		",TYPES='"+types+"'"+
        		",M1='"+m1+"'"+
        		",M='"+m+"'"+
        		",W1='"+w1+"'"+
        		",MEM='"+mem+"'"+
        	" where 1=1 "+
    		" and id ='"+id+"'"+
    	"";
        	DB db = new DB();
        	return db.executeSql(sql);	
	}
	public Map<String,Object> findPriceById(HttpServletRequest req){
         String id=req.getParameter("id");
		String sql ="select * from TBL_PRICE where 1=1 "+
    		" and id ='"+id+"'"+
    	"";
    	DB db = new DB();
    	Map<String,Object> map = null;
    	List<Map<String,Object>> list = db.query(sql);
    	if(list!=null&&list.size()>0){
    		map = list.get(0);
    	}
    	return map;	
	}
	
	
	public PageModel findPriceByCondition(HttpServletRequest req){
		String rid=req.getParameter("rid")==null?"":req.getParameter("rid");
		req.setAttribute("rid", rid);
		String w=req.getParameter("w")==null?"":req.getParameter("w");
		req.setAttribute("w", w);
		String pid=req.getParameter("pid")==null?"":req.getParameter("pid");
		req.setAttribute("pid", pid);
		String types=req.getParameter("types")==null?"":req.getParameter("types");
		req.setAttribute("types", types);
		String m1=req.getParameter("m1")==null?"":req.getParameter("m1");
		req.setAttribute("m1", m1);
		String m=req.getParameter("m")==null?"":req.getParameter("m");
		req.setAttribute("m", m);
		String w1=req.getParameter("w1")==null?"":req.getParameter("w1");
		req.setAttribute("w1", w1);
		String mem=req.getParameter("mem")==null?"":req.getParameter("mem");
		req.setAttribute("mem", mem);
         String id=req.getParameter("id");
		String sql ="";
		String where="";
		if(rid!=null&&!"".equals(rid)){
    		where+=" and RID like '%"+rid+"%'";
		}
		if(w!=null&&!"".equals(w)){
    		where+=" and W like '%"+w+"%'";
		}
		if(pid!=null&&!"".equals(pid)){
    		where+=" and PID = '"+pid+"'";
		}
		if(types!=null&&!"".equals(types)){
    		where+=" and TYPES like '%"+types+"%'";
		}
		if(m1!=null&&!"".equals(m1)){
    		where+=" and M1 like '%"+m1+"%'";
		}
		if(m!=null&&!"".equals(m)){
    		where+=" and M like '%"+m+"%'";
		}
		if(w1!=null&&!"".equals(w1)){
    		where+=" and W1 like '%"+w1+"%'";
		}
		if(mem!=null&&!"".equals(mem)){
    		where+=" and MEM like '%"+mem+"%'";
		}
    	String countsql ="select count(*) from TBL_PRICE where 1=1 "+where;
    	PageModel model = new PageModel();
		String tempPage = req.getParameter("currentPage");
		int currentPage = 1;
		try {
			currentPage = Integer.parseInt(tempPage);
		} catch (NumberFormatException e) {
			currentPage=1;
		}
		model.setCurrentPage(currentPage);
		String tempCount = req.getParameter("pageCount");
		int pageCount = 20;
		try {
			pageCount = Integer.parseInt(tempCount);
		} catch (NumberFormatException e) {
			pageCount=20;
		}
		model.setPageCount(pageCount);
		if("sqlserver".equals(DB.SQLTYPE)){
			if(currentPage==1){
				sql="select top "+pageCount+" dbo.getname(types,rid) RID,id,W"+
        		",dbo.getname('���͵��۸�',pid) PID"+
        		",TYPES"+
        		",M1"+
        		",M"+
        		",W1"+
        		",MEM from TBL_PRICE where 1=1 "+where+" order by  id  desc";
			}else{
				sql="select top "+pageCount+"  dbo.getname(types,rid) RID,id,W"+
				",dbo.getname('���͵��۸�',pid) PID"+
        		",TYPES"+
        		",M1"+
        		",M"+
        		",W1"+
				",MEM from TBL_PRICE where 1=1 "+where+" and   id  " +
					"not in (select top (("+currentPage+"-1)*"+pageCount+")  id  from TBL_PRICE where 1=1 "+where+" order by  id  desc) order by  id  desc";
			}
		}
    	DB db = new DB();
    	int count = Integer.parseInt(db.queryFirst(countsql));
    	model.setTotalCount(count);
    	if(count>0){
    		model.setRes(db.query(sql));
    	}
    	return model;	
	}
	
}