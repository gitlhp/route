package com.dao;

import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;

import com.util.PageModel;

public class CommonDao {
	//��ȡ��ѯȫ����sql
	public static String getSelAllSql(HttpServletRequest request){
		String table = request.getParameter("table");
		return "select * from "+table;
	}
	//��ȡ����id��ѯ��sql
	public static String getSelSqlById(HttpServletRequest request){
		String table = request.getParameter("table");
		String id = request.getParameter("id");
		return "select * from "+table +" where id="+id;
	}
	//��ȡ����idɾ����sql
	public static String getDelSql(HttpServletRequest request){
		String table = request.getParameter("table");
		String id = request.getParameter("id");
		return "delete from "+table+" where id="+id;
	}
	//��ȡ�޸ĵ�sql ����������c_��ʾ��
	public static String getUpdSql(HttpServletRequest request){
		String table = request.getParameter("table");
		String id = request.getParameter("id");
		String set=" id="+id;
		//��ȡ�����еĲ���
		Enumeration<String> en = request.getParameterNames();
		if(en!=null){
			while(en.hasMoreElements()){
				String name = en.nextElement();
				if(name.indexOf("c_")==0){
					String col = name.substring(2,name.length());
					set+=",col";
				}
			}
		}
		return "delete from "+table+" where id="+id;
	}
	public static String getCountSql(HttpServletRequest request){
		String table = request.getParameter("table");
		return "select count(*) from "+table;
	}
	public static PageModel getPageModel(HttpServletRequest request){
		PageModel model = new PageModel();
		String table = request.getParameter("table");
		String tempPage = request.getParameter("currentPage");
		int currentPage = 1;
		try {
			currentPage = Integer.parseInt(tempPage);
		} catch (NumberFormatException e) {
			currentPage=1;
		}
		model.setCurrentPage(currentPage);
		String tempCount = request.getParameter("pageCount");
		int pageCount = 20;
		try {
			pageCount = Integer.parseInt(tempCount);
		} catch (NumberFormatException e) {
			pageCount=20;
		}
		model.setPageCount(pageCount);
		String sql="";
		if("sqlserver".equals(DB.SQLTYPE)){
			if(currentPage==1){
				sql="select top "+pageCount+" * from "+table+" order by id desc";
			}else{
				sql="select top "+pageCount+" * from "+table+" where id " +
					"not in (select top (("+currentPage+"-1)*"+pageCount+") id from "+table+" order by id desc) order by id desc";
			}
		}
		model.setSql(sql);
		return model;
	}
}
