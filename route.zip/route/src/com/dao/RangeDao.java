package com.dao;
/***
*���ͷ�Χ
*/
import com.util.*;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
public class RangeDao {
	public RangeDao(){
	
	}
	public int addRange(HttpServletRequest req){
		String name=req.getParameter("name")==null?"":req.getParameter("name");
		String datetimes=req.getParameter("datetimes")==null?"":req.getParameter("datetimes");
		String mem=req.getParameter("mem")==null?"":req.getParameter("mem");
		String pid=req.getParameter("pid")==null?"":req.getParameter("pid");
		String sql ="insert into TBL_RANGE("+
        		"NAME"+
        		",DATETIMES"+
        		",MEM"+
        		",pid"+
        	") values("+
        		"'"+name+"'"+
        	        		",'"+datetimes+"'"+
        	        		",'"+mem+"'"+
        	        		",'"+pid+"'"+
        	")";
        	DB db = new DB();
        	return db.executeSql(sql);	
	}
	public int delRange(HttpServletRequest req){
         String id=req.getParameter("id");
		String sql ="delete from TBL_RANGE where 1=1 "+
    		" and id ='"+id+"'"+
    	"";
    	DB db = new DB();
    	return db.executeSql(sql);	
	}
	public int updRange(HttpServletRequest req){
		String name=req.getParameter("name")==null?"":req.getParameter("name");
		String datetimes=req.getParameter("datetimes")==null?"":req.getParameter("datetimes");
		String mem=req.getParameter("mem")==null?"":req.getParameter("mem");
		String pid=req.getParameter("pid")==null?"":req.getParameter("pid");
        String id=req.getParameter("id");
		String sql ="update TBL_RANGE set "+
        		"NAME='"+name+"'"+
        		",DATETIMES='"+datetimes+"'"+
        		",MEM='"+mem+"'"+
        		",pid='"+pid+"'"+
        	" where 1=1 "+
    		" and id ='"+id+"'"+
    	"";
        	DB db = new DB();
        	return db.executeSql(sql);	
	}
	public Map<String,Object> findRangeById(HttpServletRequest req){
         String id=req.getParameter("id");
		String sql ="select * from TBL_RANGE where 1=1 "+
    		" and id ='"+id+"'"+
    	"";
    	DB db = new DB();
    	Map<String,Object> map = null;
    	List<Map<String,Object>> list = db.query(sql);
    	if(list!=null&&list.size()>0){
    		map = list.get(0);
    	}
    	return map;	
	}
	
	
	public PageModel findRangeByCondition(HttpServletRequest req){
		String name=req.getParameter("name")==null?"":req.getParameter("name");
		req.setAttribute("name", name);
		String datetimes=req.getParameter("datetimes")==null?"":req.getParameter("datetimes");
		req.setAttribute("datetimes", datetimes);
		String mem=req.getParameter("mem")==null?"":req.getParameter("mem");
		req.setAttribute("mem", mem);
		String pid=req.getParameter("pid")==null?"":req.getParameter("pid");
		req.setAttribute("pid", pid);
         String id=req.getParameter("id");
		String sql ="";
		String where="";
		if(name!=null&&!"".equals(name)){
    		where+=" and NAME like '%"+name+"%'";
		}
		if(datetimes!=null&&!"".equals(datetimes)){
    		where+=" and DATETIMES like '%"+datetimes+"%'";
		}
		if(mem!=null&&!"".equals(mem)){
    		where+=" and MEM like '%"+mem+"%'";
		}
		if(pid!=null&&!"".equals(pid)){
			where+=" and pid = '"+pid+"'";
		}
    	String countsql ="select count(*) from TBL_RANGE where 1=1 "+where;
    	PageModel model = new PageModel();
		String tempPage = req.getParameter("currentPage");
		int currentPage = 1;
		try {
			currentPage = Integer.parseInt(tempPage);
		} catch (NumberFormatException e) {
			currentPage=1;
		}
		model.setCurrentPage(currentPage);
		String tempCount = req.getParameter("pageCount");
		int pageCount = 20;
		try {
			pageCount = Integer.parseInt(tempCount);
		} catch (NumberFormatException e) {
			pageCount=20;
		}
		model.setPageCount(pageCount);
		if("sqlserver".equals(DB.SQLTYPE)){
			if(currentPage==1){
				sql="select top "+pageCount+" * from TBL_RANGE where 1=1 "+where+" order by  id  desc";
			}else{
				sql="select top "+pageCount+" * from TBL_RANGE where 1=1 "+where+" and   id  " +
					"not in (select top (("+currentPage+"-1)*"+pageCount+")  id  from TBL_RANGE where 1=1 "+where+" order by  id  desc) order by  id  desc";
			}
		}
    	DB db = new DB();
    	int count = Integer.parseInt(db.queryFirst(countsql));
    	model.setTotalCount(count);
    	if(count>0){
    		model.setRes(db.query(sql));
    	}
    	return model;	
	}
	
}