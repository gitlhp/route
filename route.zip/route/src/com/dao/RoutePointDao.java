package com.dao;
/***
*��·����
*/
import com.util.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
public class RoutePointDao {
	public RoutePointDao(){
	
	}
	public int addRoutePoint(HttpServletRequest req){
		String pid=req.getParameter("pid")==null?"":req.getParameter("pid");
		String rid=req.getParameter("rid")==null?"":req.getParameter("rid");
		String num=req.getParameter("num")==null?"":req.getParameter("num");
		String sql ="insert into TBL_ROUTE_POINT("+
        		"PID"+
        		",RID"+
        		",NUM"+
        	") values("+
        		"'"+pid+"'"+
        	        		",'"+rid+"'"+
        	        		",'"+num+"'"+
        	")";
        	DB db = new DB();
        	return db.executeSql(sql);	
	}
	public int delRoutePoint(HttpServletRequest req){
         String id=req.getParameter("id");
		String sql ="delete from TBL_ROUTE_POINT where 1=1 "+
    		" and id ='"+id+"'"+
    	"";
    	DB db = new DB();
    	return db.executeSql(sql);	
	}
	public int updRoutePoint(HttpServletRequest req){
		String rid=req.getParameter("rid")==null?"":req.getParameter("rid");
		String sql ="delete from TBL_ROUTE_POINT "+
        	" where 1=1 "+
    		" and rid ='"+rid+"'"+
    	"";
		List<String> list = new ArrayList<String>();
		list.add(sql);
        	DB db = new DB();
        	int i=0;
        	while(i>=0){
        		String pid=req.getParameter("pid"+i);
        		String num=req.getParameter("num"+i);
        		if(pid==null||num==null){
        			i=-1;
        		}else{
        			i++;
        			if(pid==null||"".equals(pid.trim())){
        				continue;
        			}
        			if(num==null||"".equals(num)){
        				num="0";
        			}
        			list.add("insert into TBL_ROUTE_POINT("+
        		"PID"+
        		",RID"+
        		",NUM"+
        	") values("+
        		"'"+pid+"'"+
        	        		",'"+rid+"'"+
        	        		",'"+num+"'"+
        	")");
        		}
        	}
        	return db.batchSql(list);	
	}
	public List<Map<String,Object>> findRoutePointById(HttpServletRequest req){
         String id=req.getParameter("id");
		String sql ="select r.name,r.id rid,t.pid,t.num from TBL_ROUTE r left join TBL_ROUTE_POINT t on r.id=t.rid where 1=1 "+
    		" and r.id ='"+id+"'"+
    	"";
    	DB db = new DB();
    	Map<String,Object> map = null;
    	List<Map<String,Object>> list = db.query(sql);
    	return list;	
	}
	
	
	public PageModel findRoutePointByCondition(HttpServletRequest req){
		String pid=req.getParameter("pid")==null?"":req.getParameter("pid");
		req.setAttribute("pid", pid);
		String rid=req.getParameter("rid")==null?"":req.getParameter("rid");
		req.setAttribute("rid", rid);
		String num=req.getParameter("num")==null?"":req.getParameter("num");
		req.setAttribute("num", num);
         String id=req.getParameter("id");
		String sql ="";
		String where="";
		if(pid!=null&&!"".equals(pid)){
    		where+=" and PID like '%"+pid+"%'";
		}
		if(rid!=null&&!"".equals(rid)){
    		where+=" and RID like '%"+rid+"%'";
		}
		if(num!=null&&!"".equals(num)){
    		where+=" and NUM like '%"+num+"%'";
		}
    	String countsql ="select count(*) from TBL_ROUTE_POINT where 1=1 "+where;
    	PageModel model = new PageModel();
		String tempPage = req.getParameter("currentPage");
		int currentPage = 1;
		try {
			currentPage = Integer.parseInt(tempPage);
		} catch (NumberFormatException e) {
			currentPage=1;
		}
		model.setCurrentPage(currentPage);
		String tempCount = req.getParameter("pageCount");
		int pageCount = 20;
		try {
			pageCount = Integer.parseInt(tempCount);
		} catch (NumberFormatException e) {
			pageCount=20;
		}
		model.setPageCount(pageCount);
		if("sqlserver".equals(DB.SQLTYPE)){
			if(currentPage==1){
				sql="select top "+pageCount+" * from TBL_ROUTE_POINT where 1=1 "+where+" order by  id  desc";
			}else{
				sql="select top "+pageCount+" * from TBL_ROUTE_POINT where 1=1 "+where+" and   id  " +
					"not in (select top (("+currentPage+"-1)*"+pageCount+")  id  from TBL_ROUTE_POINT where 1=1 "+where+" order by  id  desc) order by  id  desc";
			}
		}
    	DB db = new DB();
    	int count = Integer.parseInt(db.queryFirst(countsql));
    	model.setTotalCount(count);
    	if(count>0){
    		model.setRes(db.query(sql));
    	}
    	return model;	
	}
	
}