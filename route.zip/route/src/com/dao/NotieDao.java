package com.dao;
/***
*���Ź���
*/
import com.util.*;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
public class NotieDao {
	public NotieDao(){
	
	}
	public int addNotie(HttpServletRequest req){
		String title=req.getParameter("title")==null?"":req.getParameter("title");
		String content=req.getParameter("content")==null?"":req.getParameter("content");
		String img=req.getParameter("img")==null?"":req.getParameter("img");
		String types=req.getParameter("types")==null?"":req.getParameter("types");
		String sql ="insert into NOTIE("+
        		"TITLE"+
        		",CONTENT"+
        		",IMG"+
        		",DATETIMES"+
        		",types"+
        	") values("+
        		"'"+title+"'"+
        	        		",'"+content+"'"+
        	        		",'"+img+"'"+
        	        		",getdate()"+
        	        		",'"+types+"'"+
        	")";
        	DB db = new DB();
        	return db.executeSql(sql);	
	}
	public int delNotie(HttpServletRequest req){
         String id=req.getParameter("id");
		String sql ="delete from NOTIE where 1=1 "+
    		" and id ='"+id+"'"+
    	"";
    	DB db = new DB();
    	return db.executeSql(sql);	
	}
	public int updNotie(HttpServletRequest req){
		String title=req.getParameter("title")==null?"":req.getParameter("title");
		String content=req.getParameter("content")==null?"":req.getParameter("content");
		String img=req.getParameter("img")==null?"":req.getParameter("img");
		String types=req.getParameter("types")==null?"":req.getParameter("types");
        String id=req.getParameter("id");
		String sql ="update NOTIE set "+
        		"TITLE='"+title+"'"+
        		",CONTENT='"+content+"'"+
        		",IMG='"+img+"'"+
        		",types='"+types+"'"+
        		",DATETIMES=getdate()"+
        	" where 1=1 "+
    		" and id ='"+id+"'"+
    	"";
        	DB db = new DB();
        	return db.executeSql(sql);	
	}
	public Map<String,Object> findNotieById(HttpServletRequest req){
         String id=req.getParameter("id");
		String sql ="select * from NOTIE where 1=1 "+
    		" and id ='"+id+"'"+
    	"";
    	DB db = new DB();
    	Map<String,Object> map = null;
    	List<Map<String,Object>> list = db.query(sql);
    	if(list!=null&&list.size()>0){
    		map = list.get(0);
    	}
    	return map;	
	}
	
	
	public PageModel findNotieByCondition(HttpServletRequest req){
		String title=req.getParameter("title")==null?"":req.getParameter("title");
		req.setAttribute("title", title);
		String content=req.getParameter("content")==null?"":req.getParameter("content");
		req.setAttribute("content", content);
		String img=req.getParameter("img")==null?"":req.getParameter("img");
		req.setAttribute("img", img);
		String datetimes=req.getParameter("datetimes")==null?"":req.getParameter("datetimes");
		req.setAttribute("datetimes", datetimes);
		String types=req.getParameter("types")==null?"":req.getParameter("types");
		req.setAttribute("types", types);
         String id=req.getParameter("id");
		String sql ="";
		String where="";
		if(title!=null&&!"".equals(title)){
    		where+=" and TITLE like '%"+title+"%'";
		}
		if(content!=null&&!"".equals(content)){
    		where+=" and CONTENT like '%"+content+"%'";
		}
		if(types!=null&&!"".equals(types)){
			where+=" and types = '"+types+"'";
		}
		if(img!=null&&!"".equals(img)){
    		where+=" and IMG like '%"+img+"%'";
		}
    	String countsql ="select count(*) from NOTIE where 1=1 "+where;
    	PageModel model = new PageModel();
		String tempPage = req.getParameter("currentPage");
		int currentPage = 1;
		try {
			currentPage = Integer.parseInt(tempPage);
		} catch (NumberFormatException e) {
			currentPage=1;
		}
		model.setCurrentPage(currentPage);
		String tempCount = req.getParameter("pageCount");
		int pageCount = 20;
		try {
			pageCount = Integer.parseInt(tempCount);
		} catch (NumberFormatException e) {
			pageCount=20;
		}
		model.setPageCount(pageCount);
		if("sqlserver".equals(DB.SQLTYPE)){
			if(currentPage==1){
				sql="select top "+pageCount+" convert(varchar, datetimes, 120) datetimes,title,content,id from NOTIE where 1=1 "+where+" order by  id  desc";
			}else{
				sql="select top "+pageCount+" convert(varchar, datetimes, 120) datetimes,title,content,id from NOTIE where 1=1 "+where+" and   id  " +
					"not in (select top (("+currentPage+"-1)*"+pageCount+")  id  from NOTIE where 1=1 "+where+" order by  id  desc) order by  id  desc";
			}
		}
    	DB db = new DB();
    	int count = Integer.parseInt(db.queryFirst(countsql));
    	model.setTotalCount(count);
    	if(count>0){
    		model.setRes(db.query(sql));
    	}
    	return model;	
	}
	
}