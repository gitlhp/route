package com.dao;
/***
*����ֳ�����
*/
import com.util.*;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
public class ConfigDao {
	public ConfigDao(){
	
	}
	public int addConfig(HttpServletRequest req){
		String p=req.getParameter("p")==null?"":req.getParameter("p");
		String r=req.getParameter("r")==null?"":req.getParameter("r");
		String s=req.getParameter("s")==null?"":req.getParameter("s");
		String sql ="insert into TBL_CONFIG("+
        		"P"+
        		",R"+
        		",S"+
        	") values("+
        		"'"+p+"'"+
        	        		",'"+r+"'"+
        	        		",'"+s+"'"+
        	")";
        	DB db = new DB();
        	return db.executeSql(sql);	
	}
	public int delConfig(HttpServletRequest req){
         String id=req.getParameter("id");
		String sql ="delete from TBL_CONFIG where 1=1 "+
    		" and id ='"+id+"'"+
    	"";
    	DB db = new DB();
    	return db.executeSql(sql);	
	}
	public int updConfig(HttpServletRequest req){
		String p=req.getParameter("p")==null?"":req.getParameter("p");
		String r=req.getParameter("r")==null?"":req.getParameter("r");
		String s=req.getParameter("s")==null?"":req.getParameter("s");
        String id=req.getParameter("id");
		String sql ="update TBL_CONFIG set "+
        		"P='"+p+"'"+
        		",R='"+r+"'"+
        		",S='"+s+"'"+
        	" where 1=1 "+
    		" and id ='"+id+"'"+
    	"";
        	DB db = new DB();
        	return db.executeSql(sql);	
	}
	public Map<String,Object> findConfigById(HttpServletRequest req){
         String id=req.getParameter("id");
		String sql ="select * from TBL_CONFIG where 1=1 "+
    		" and id ='"+id+"'"+
    	"";
    	DB db = new DB();
    	Map<String,Object> map = null;
    	List<Map<String,Object>> list = db.query(sql);
    	if(list!=null&&list.size()>0){
    		map = list.get(0);
    	}
    	return map;	
	}
	
	
	public PageModel findConfigByCondition(HttpServletRequest req){
		String p=req.getParameter("p")==null?"":req.getParameter("p");
		req.setAttribute("p", p);
		String r=req.getParameter("r")==null?"":req.getParameter("r");
		req.setAttribute("r", r);
		String s=req.getParameter("s")==null?"":req.getParameter("s");
		req.setAttribute("s", s);
         String id=req.getParameter("id");
		String sql ="";
		String where="";
		if(p!=null&&!"".equals(p)){
    		where+=" and P like '%"+p+"%'";
		}
		if(r!=null&&!"".equals(r)){
    		where+=" and R like '%"+r+"%'";
		}
		if(s!=null&&!"".equals(s)){
    		where+=" and S like '%"+s+"%'";
		}
    	String countsql ="select count(*) from TBL_CONFIG where 1=1 "+where;
    	PageModel model = new PageModel();
		String tempPage = req.getParameter("currentPage");
		int currentPage = 1;
		try {
			currentPage = Integer.parseInt(tempPage);
		} catch (NumberFormatException e) {
			currentPage=1;
		}
		model.setCurrentPage(currentPage);
		String tempCount = req.getParameter("pageCount");
		int pageCount = 20;
		try {
			pageCount = Integer.parseInt(tempCount);
		} catch (NumberFormatException e) {
			pageCount=20;
		}
		model.setPageCount(pageCount);
		if("sqlserver".equals(DB.SQLTYPE)){
			if(currentPage==1){
				sql="select top "+pageCount+" * from TBL_CONFIG where 1=1 "+where+" order by  id  desc";
			}else{
				sql="select top "+pageCount+" * from TBL_CONFIG where 1=1 "+where+" and   id  " +
					"not in (select top (("+currentPage+"-1)*"+pageCount+")  id  from TBL_CONFIG where 1=1 "+where+" order by  id  desc) order by  id  desc";
			}
		}
    	DB db = new DB();
    	int count = Integer.parseInt(db.queryFirst(countsql));
    	model.setTotalCount(count);
    	if(count>0){
    		model.setRes(db.query(sql));
    	}
    	return model;	
	}
	
}