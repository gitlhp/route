package com.dao;
/***
*��·����
*/
import com.util.*;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
public class RouteDao {
	public RouteDao(){
	
	}
	public int addRoute(HttpServletRequest req){
		String name=req.getParameter("name")==null?"":req.getParameter("name");
		String sql ="insert into TBL_ROUTE("+
        		"NAME"+
        	") values("+
        		"'"+name+"'"+
        	")";
        	DB db = new DB();
        	return db.executeSql(sql);	
	}
	public int delRoute(HttpServletRequest req){
         String id=req.getParameter("id");
		String sql ="delete from TBL_ROUTE where 1=1 "+
    		" and id ='"+id+"'"+
    	"";
    	DB db = new DB();
    	return db.executeSql(sql);	
	}
	public int updRoute(HttpServletRequest req){
		String name=req.getParameter("name")==null?"":req.getParameter("name");
        String id=req.getParameter("id");
		String sql ="update TBL_ROUTE set "+
        		"NAME='"+name+"'"+
        	" where 1=1 "+
    		" and id ='"+id+"'"+
    	"";
        	DB db = new DB();
        	return db.executeSql(sql);	
	}
	public Map<String,Object> findRouteById(HttpServletRequest req){
         String id=req.getParameter("id");
		String sql ="select * from TBL_ROUTE where 1=1 "+
    		" and id ='"+id+"'"+
    	"";
    	DB db = new DB();
    	Map<String,Object> map = null;
    	List<Map<String,Object>> list = db.query(sql);
    	if(list!=null&&list.size()>0){
    		map = list.get(0);
    	}
    	return map;	
	}
	
	
	public PageModel findRouteByCondition(HttpServletRequest req){
		String name=req.getParameter("name")==null?"":req.getParameter("name");
		req.setAttribute("name", name);
         String id=req.getParameter("id");
		String sql ="";
		String where="";
		if(name!=null&&!"".equals(name)){
    		where+=" and NAME like '%"+name+"%'";
		}
    	String countsql ="select count(*) from TBL_ROUTE where 1=1 "+where;
    	PageModel model = new PageModel();
		String tempPage = req.getParameter("currentPage");
		int currentPage = 1;
		try {
			currentPage = Integer.parseInt(tempPage);
		} catch (NumberFormatException e) {
			currentPage=1;
		}
		model.setCurrentPage(currentPage);
		String tempCount = req.getParameter("pageCount");
		int pageCount = 20;
		try {
			pageCount = Integer.parseInt(tempCount);
		} catch (NumberFormatException e) {
			pageCount=20;
		}
		model.setPageCount(pageCount);
		if("sqlserver".equals(DB.SQLTYPE)){
			if(currentPage==1){
				sql="select top "+pageCount+" * from TBL_ROUTE where 1=1 "+where+" order by  id  desc";
			}else{
				sql="select top "+pageCount+" * from TBL_ROUTE where 1=1 "+where+" and   id  " +
					"not in (select top (("+currentPage+"-1)*"+pageCount+")  id  from TBL_ROUTE where 1=1 "+where+" order by  id  desc) order by  id  desc";
			}
		}
    	DB db = new DB();
    	int count = Integer.parseInt(db.queryFirst(countsql));
    	model.setTotalCount(count);
    	if(count>0){
    		model.setRes(db.query(sql));
    	}
    	return model;	
	}
	
}