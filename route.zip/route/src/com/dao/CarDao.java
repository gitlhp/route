package com.dao;
/***
*����
*/
import com.util.*;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
public class CarDao {
	public CarDao(){
	
	}
	public int addCar(HttpServletRequest req){
		String name=req.getParameter("name")==null?"":req.getParameter("name");
		String state=req.getParameter("state")==null?"":req.getParameter("state");
		String weight=req.getParameter("weight")==null?"":req.getParameter("weight");
		String m=req.getParameter("m")==null?"":req.getParameter("m");
		String sql ="insert into TBL_CAR("+
        		"NAME"+
        		",STATE"+
        		",WEIGHT"+
        		",M"+
        	") values("+
        		"'"+name+"'"+
        	        		",'"+state+"'"+
        	        		",'"+weight+"'"+
        	        		",'"+m+"'"+
        	")";
        	DB db = new DB();
        	return db.executeSql(sql);	
	}
	public int delCar(HttpServletRequest req){
         String id=req.getParameter("id");
		String sql ="delete from TBL_CAR where 1=1 "+
    		" and id ='"+id+"'"+
    	"";
    	DB db = new DB();
    	return db.executeSql(sql);	
	}
	public int updCar(HttpServletRequest req){
		String name=req.getParameter("name")==null?"":req.getParameter("name");
		String state=req.getParameter("state")==null?"":req.getParameter("state");
		String weight=req.getParameter("weight")==null?"":req.getParameter("weight");
		String m=req.getParameter("m")==null?"":req.getParameter("m");
        String id=req.getParameter("id");
		String sql ="update TBL_CAR set "+
        		"NAME='"+name+"'"+
        		",STATE='"+state+"'"+
        		",WEIGHT='"+weight+"'"+
        		",M='"+m+"'"+
        	" where 1=1 "+
    		" and id ='"+id+"'"+
    	"";
        	DB db = new DB();
        	return db.executeSql(sql);	
	}
	public Map<String,Object> findCarById(HttpServletRequest req){
         String id=req.getParameter("id");
		String sql ="select * from TBL_CAR where 1=1 "+
    		" and id ='"+id+"'"+
    	"";
    	DB db = new DB();
    	Map<String,Object> map = null;
    	List<Map<String,Object>> list = db.query(sql);
    	if(list!=null&&list.size()>0){
    		map = list.get(0);
    	}
    	return map;	
	}
	
	
	public PageModel findCarByCondition(HttpServletRequest req){
		String name=req.getParameter("name")==null?"":req.getParameter("name");
		req.setAttribute("name", name);
		String state=req.getParameter("state")==null?"":req.getParameter("state");
		req.setAttribute("state", state);
		String weight=req.getParameter("weight")==null?"":req.getParameter("weight");
		req.setAttribute("weight", weight);
		String m=req.getParameter("m")==null?"":req.getParameter("m");
		req.setAttribute("m", m);
         String id=req.getParameter("id");
		String sql ="";
		String where="";
		if(name!=null&&!"".equals(name)){
    		where+=" and NAME like '%"+name+"%'";
		}
		if(state!=null&&!"".equals(state)){
    		where+=" and STATE like '%"+state+"%'";
		}
		if(weight!=null&&!"".equals(weight)){
    		where+=" and WEIGHT like '%"+weight+"%'";
		}
		if(m!=null&&!"".equals(m)){
    		where+=" and M like '%"+m+"%'";
		}
    	String countsql ="select count(*) from TBL_CAR where 1=1 "+where;
    	PageModel model = new PageModel();
		String tempPage = req.getParameter("currentPage");
		int currentPage = 1;
		try {
			currentPage = Integer.parseInt(tempPage);
		} catch (NumberFormatException e) {
			currentPage=1;
		}
		model.setCurrentPage(currentPage);
		String tempCount = req.getParameter("pageCount");
		int pageCount = 20;
		try {
			pageCount = Integer.parseInt(tempCount);
		} catch (NumberFormatException e) {
			pageCount=20;
		}
		model.setPageCount(pageCount);
		if("sqlserver".equals(DB.SQLTYPE)){
			if(currentPage==1){
				sql="select top "+pageCount+" * from TBL_CAR where 1=1 "+where+" order by  id  desc";
			}else{
				sql="select top "+pageCount+" * from TBL_CAR where 1=1 "+where+" and   id  " +
					"not in (select top (("+currentPage+"-1)*"+pageCount+")  id  from TBL_CAR where 1=1 "+where+" order by  id  desc) order by  id  desc";
			}
		}
    	DB db = new DB();
    	int count = Integer.parseInt(db.queryFirst(countsql));
    	model.setTotalCount(count);
    	if(count>0){
    		model.setRes(db.query(sql));
    	}
    	return model;	
	}
	
}