package com.dao;
/***
*write by createfile 
*���ѽ��
*/
import com.util.*;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
public class AmountDao {
	public AmountDao(){
	
	}
	public int addAmount(HttpServletRequest req){
		String userid=req.getParameter("userid")==null?"":req.getParameter("userid");
		String am=req.getParameter("am")==null?"":req.getParameter("am");
		String credit=req.getParameter("credit")==null?"":req.getParameter("credit");
		String sql ="insert into AMOUNT("+
        		"USERID"+
        		",AM"+
        		",CREDIT"+
        	",dates) values("+
        		"'"+userid+"'"+
        	        		",'"+am+"'"+
        	        		",'"+credit+"'"+
        	",getdate())";
        	DB db = new DB();
        	return db.executeSql(sql);	
	}
	public int delAmount(HttpServletRequest req){
         String id=req.getParameter("id");
		String sql ="delete from AMOUNT where 1=1 "+
    		" and id ='"+id+"'"+
    	"";
    	DB db = new DB();
    	return db.executeSql(sql);	
	}
	public int updAmount(HttpServletRequest req){
		String userid=req.getParameter("userid")==null?"":req.getParameter("userid");
		String am=req.getParameter("am")==null?"":req.getParameter("am");
		String credit=req.getParameter("credit")==null?"":req.getParameter("credit");
        String id=req.getParameter("id");
		String sql ="update AMOUNT set "+
        		"USERID='"+userid+"'"+
        		",AM='"+am+"'"+
        		",CREDIT='"+credit+"',dates=getdate()"+
        	" where 1=1 "+
    		" and id ='"+id+"'"+
    	"";
        	DB db = new DB();
        	return db.executeSql(sql);	
	}
	public Map<String,Object> findAmountById(HttpServletRequest req){
         String id=req.getParameter("id");
		String sql ="select * from AMOUNT where 1=1 "+
    		" and id ='"+id+"'"+
    	"";
    	DB db = new DB();
    	Map<String,Object> map = null;
    	List<Map<String,Object>> list = db.query(sql);
    	if(list!=null&&list.size()>0){
    		map = list.get(0);
    	}
    	return map;	
	}
	
	
	public PageModel findAmountByCondition(HttpServletRequest req){
		String userid=req.getParameter("userid")==null?"":req.getParameter("userid");
		req.setAttribute("userid", userid);
		String am=req.getParameter("am")==null?"":req.getParameter("am");
		req.setAttribute("am", am);
		String credit=req.getParameter("credit")==null?"":req.getParameter("credit");
		req.setAttribute("credit", credit);
         String id=req.getParameter("id");
		String sql ="";
		String where="";
		if(userid!=null&&!"".equals(userid)){
    		where+=" and a.USERID like '%"+userid+"%'";
		}
		if(am!=null&&!"".equals(am)){
    		where+=" and a.AM like '%"+am+"%'";
		}
		if(credit!=null&&!"".equals(credit)){
    		where+=" and a.CREDIT like '%"+credit+"%'";
		}
    	String countsql ="select count(*) from AMOUNT a where 1=1 "+where;
    	PageModel model = new PageModel();
		String tempPage = req.getParameter("currentPage");
		int currentPage = 1;
		try {
			currentPage = Integer.parseInt(tempPage);
		} catch (NumberFormatException e) {
			currentPage=1;
		}
		model.setCurrentPage(currentPage);
		String tempCount = req.getParameter("pageCount");
		int pageCount = 20;
		try {
			pageCount = Integer.parseInt(tempCount);
		} catch (NumberFormatException e) {
			pageCount=20;
		}
		model.setPageCount(pageCount);
		if("sqlserver".equals(DB.SQLTYPE)){
			if(currentPage==1){
				sql="select top "+pageCount+" s.username userid,convert(varchar(100),dates,20) dates,a.id,a.am,a.credit from AMOUNT a left join users s on s.userid=a.userid where 1=1 "+where+" order by  id  desc";
			}else{
				sql="select top "+pageCount+" s.username userid,convert(varchar(100),dates,20) dates,a.id,a.am,a.credit from AMOUNT a left join users s on s.userid=a.userid  where 1=1 "+where+" and   id  " +
					"not in (select top (("+currentPage+"-1)*"+pageCount+")  id  from AMOUNT a where 1=1 "+where+" order by  id  desc) order by  id  desc";
			}
		}
    	DB db = new DB();
    	int count = Integer.parseInt(db.queryFirst(countsql));
    	model.setTotalCount(count);
    	if(count>0){
    		model.setRes(db.query(sql));
    	}
    	return model;	
	}
	
}