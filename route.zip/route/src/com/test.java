package com;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class test {
	public static void main(String[] args) {
		dl();
	}
	public static void dl(){
		Set<String> s = getName();
		System.out.println("����"+s.size()+"��");
		for (Iterator iter = s.iterator(); iter.hasNext();) {
			String str = (String) iter.next();
			try {
				File f =new File("C:\\Users\\cc\\Desktop\\temp"+str);
				System.out.println("��������"+"http://www.ztsm888.com"+str);
				if(f.exists()){
					continue;
				}
				URL url = new URL("http://www.ztsm888.com"+str);
				HttpURLConnection con = (HttpURLConnection)url.openConnection();
				con.connect();
				InputStream in =con.getInputStream();
				byte[] b=new byte[1024];
				FileOutputStream out = new FileOutputStream(f);
				int len=0;
				while((len=in.read(b))!=-1){
					out.write(b, 0, len);
				}
				out.close();
				in.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		System.out.println("end...");
	}
	public static Set<String> getName(){
		File f = new File("C:\\Users\\cc\\Desktop\\temp\\index_files");
		Set<String> set = new HashSet<String>();
		File[] fs =f.listFiles(new FilenameFilter(){
			public boolean accept(File dir, String name) {
				if(name.contains(".css")){
					return true;
				}
				return false;
			}
		});
		for (int i = 0; i < fs.length; i++) {
			try {
				BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(fs[i])));
				String line = reader.readLine();
				Pattern pattern = Pattern.compile("/.*\\.(gif|jpg|png)");
				while(line!=null){
					Matcher m =pattern.matcher(line);
					while (m.find()) {
						set.add(m.group());
					}
					line = reader.readLine();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return set;
	}
}
