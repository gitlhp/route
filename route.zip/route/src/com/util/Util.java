package com.util;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletResponse;

public class Util {

	/**
	 * ����ʱclass��λ��
	 */
	public static final String APP_CLASS_PATH=Util.class.getClassLoader().getResource("").getPath().substring(1, Util.class.getClassLoader().getResource("").getPath().length());
	/**
	 * �����ռ�SRC��λ��
	 */
	public static final String APP_WORKSPACE_SRC_PATH=System.getProperty("user.dir")+"\\src\\";
	/**
	 * �����ռ�WEBROOT��λ��
	 */
	public static final String APP_WORKSPACE_WEBROOT_PATH=System.getProperty("user.dir")+"\\WebRoot\\";
	public static	PropertyResourceBundle getPropertyResourceBundle(String fileName){
		return (PropertyResourceBundle) PropertyResourceBundle.getBundle(fileName);
	}
	public static String getPropertyResourceBundleValue(String fileName,String key){
		return getPropertyResourceBundle(fileName).getString(key);
	}
	/**
	 * д��Property�ļ�
	 * @param fileName
	 * @param map
	 */
	public static void setPropertyResourceBundleValue(String fileName,Map<String,String> map){
		Properties properties = new Properties();
		try {
			FileOutputStream out = new FileOutputStream(APP_WORKSPACE_SRC_PATH+(fileName+".properties"));
			properties.putAll(map);
			properties.store(out, "author:qq75155953");
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}
	/**
	 *�ַ����滻
	 *@param strFrom Ҫ�滻��Ŀ���Ӵ�
	 *@param strTo �滻����Ӵ�
	 *@param strSource ԭ�ַ���
	 *@return �滻����ַ���
	 */
	public static String replace(String strSource, String strFrom, String strTo) {
		String strDest = "";

		int intFromLen = strFrom.length();
		int intPos;
		while ((intPos = strSource.indexOf(strFrom)) != -1) {
			strDest = strDest + strSource.substring(0, intPos);
			strDest = strDest + strTo;
			strSource = strSource.substring(intPos + intFromLen);
		}
		strDest = strDest + strSource;

		return strDest;
	}

	/**
	 *����һ���ַ����е��Ӵ�����,
	 */
	public static int childStrNo(String str, String delim) {
		int cur = 0;
		int numno = 1;
		do {

			cur = str.indexOf(delim);
			if (cur == -1) {
				break;
			}
			str = str.substring(cur + 1, str.length());
			numno = numno + 1;
		} while (true);

		return numno;

	}


	/**
	 *�ַ����ָ�
	 * @param str ԭ�ַ���
	 * @param delim �ָ��Ӵ�
	 * @return String[]
	 */
	public static String[] split(String str, String delim) {
		int last = 0;
		int cur = 0;
		String[] result = null;
		ArrayList holder = new ArrayList();

		do {
			String tmp;
			cur = str.indexOf(delim, cur);
			if (cur == -1) {
				tmp = str.substring(last);
				holder.add(tmp);
				break;
			}
			tmp = str.substring(last, cur);
			holder.add(tmp);
			cur += delim.length();
			last = cur;
		} while (true);
		result = new String[holder.size()];
		for (int i = 0; i < holder.size(); i++) {
			result[i] = (String) holder.get(i);
		}

		return result;
	}

	/**
	 * ��ISO-8859-1����ת��Ϊ GB2312
	 * @param str Ŀ���ַ���
	 * @return String
	 */
	public static String ISOtoGb2312(String str) {
		if (str == null) {
			return " ";
		}
		try {
			byte[] bytesStr = str.getBytes("ISO-8859-1");
			return new String(bytesStr, "GB2312");
		} catch (Exception ex) {
			return str;
		}
	}
	/**
	 * ��ISO-8859-1����ת��Ϊ GB2312
	 * @param str Ŀ���ַ���
	 * @return String
	 */
	public static String ISOtoUTF8(String str) {
		if (str == null) {
			return " ";
		}
		try {
			byte[] bytesStr = str.getBytes("ISO-8859-1");
			return new String(bytesStr, "UTF-8");
		} catch (Exception ex) {
			return str;
		}
	}

	public static String Gb2312toISO(String str) {
		if (str == null) {
			return " ";
		}
		try {
			byte[] bytesStr = str.getBytes("GBK");
			return new String(bytesStr, "ISO-8859-1");
		} catch (Exception ex) {
			return str;
		}
	}

	/**
	 * �������ַ���
	 * @param strҪ�������ַ��� ���strΪnull����""
	 * @return String ���strΪnull����"" ���򷵻�str
	 */
	public static String dealNull(String str) {
		String returnstr = null;
		if (str == null) {
			returnstr = "";
		} else {
			returnstr = str;
		}
		return returnstr;
	}

	/**
	 *�����ն���
	 *��nullת��Ϊ""����
	 * @param obj:Object
	 * @return Object
	 */
	public static Object dealNull(Object obj) {
		Object returnstr = null;
		if (obj == null) {
			returnstr = (Object) ("");
		} else {
			returnstr = obj;
		}
		return returnstr;
	}

	/**
	 *���ַ���ת��Ϊ����
	 *�������Ϊnull�򡰡�����ת��Ϊ�����򷵻�0
	 *�硰������23�����ؽ��Ϊ0
	 */
	public static int intToString(String s) {
		s = dealNull(s);
		int x = 0;
		if (s.equals("")) {
			return 0;
		}
		try {
			x = Integer.parseInt(s);
		} catch (Exception e) {}
		return x;
	}

	/**
	 *���Ƿ�Ϊ��������
	 * @param number
	 * @return boolean:true or false
	 */
	public static boolean isInt(String number) {
		try {
			Integer.parseInt(number);
			return true;
		} catch (NumberFormatException sqo) {
			return false;
		}
	}

	/**
	 * �ַ���ת��Ϊjava.util.Date<br>
	 * ֧�ָ�ʽΪ yyyy.MM.dd G 'at' hh:mm:ss z �� '2002-1-1 AD at 22:10:59 PSD'<br>
	 * yy/MM/dd HH:mm:ss �� '2002/1/1 17:55:00'<br>
	 * yy/MM/dd HH:mm:ss pm  �� '2002/1/1 17:55:00 pm'<br>
	 * yy-MM-dd HH:mm:ss �� '2002-1-1 17:55:00' <br>
	 * yy-MM-dd HH:mm:ss am �� '2002-1-1 17:55:00 am' <br>
	 * @param time String �ַ���<br>
	 * @return Date ����<br>
	 */
	public static Date stringToDate(String time) {
		SimpleDateFormat formatter;
		int tempPos = time.indexOf("AD");
		time = time.trim();
		formatter = new SimpleDateFormat("yyyy.MM.dd G 'at' hh:mm:ss z");
		if (tempPos > -1) {
			time = time.substring(0, tempPos) +
			"��Ԫ" + time.substring(tempPos + "AD".length()); //china
			formatter = new SimpleDateFormat("yyyy.MM.dd G 'at' hh:mm:ss z");
		}
		tempPos = time.indexOf("-");
		if (tempPos > -1 && (time.indexOf(" ") < 0)) {
			formatter = new SimpleDateFormat("yyyyMMddHHmmssZ");
		} else if ((time.indexOf("/") > -1) && (time.indexOf(" ") > -1)) {
			formatter = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		} else if ((time.indexOf("-") > -1) && (time.indexOf(" ") > -1)) {
			formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		} else if ((time.indexOf("/") > -1) && (time.indexOf("am") > -1) ||
				(time.indexOf("pm") > -1)) {
			formatter = new SimpleDateFormat("yyyy-MM-dd KK:mm:ss a");
		} else if ((time.indexOf("-") > -1) && (time.indexOf("am") > -1) ||
				(time.indexOf("pm") > -1)) {
			formatter = new SimpleDateFormat("yyyy-MM-dd KK:mm:ss a");
		}
		ParsePosition pos = new ParsePosition(0);
		java.util.Date ctime = formatter.parse(time, pos);

		return ctime;
	}

	/**
	 * ��java.util.Date ��ʽת��Ϊ�ַ�����ʽ'yyyy-MM-dd HH:mm:ss'(24Сʱ��)<br>
	 * ��Sat May 11 17:24:21 CST 2002 to '2002-05-11 17:24:21'<br>
	 * @param time Date ����<br>
	 * @return String   �ַ���<br>
	 */

	public static String dateToString(Date time) {
		SimpleDateFormat formatter;
		formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String ctime = formatter.format(time);

		return ctime;
	}

	/**
	 * ��java.util.Date ��ʽת��Ϊ�ַ�����ʽ'yyyyMMddHHmmss'(24Сʱ��)<br>
	 * ��Sat May 11 17:24:21 CST 2002 to '2002-05-11 17:24:21'<br>
	 * @param time Date ����<br>
	 * @return String   �ַ���<br>
	 */

	public static String dateToString11(Date time) {
		SimpleDateFormat formatter;
		formatter = new SimpleDateFormat("yyyyMMddHHmmss");
		String ctime = formatter.format(time);

		return ctime;
	}

	/**
	 * ��java.util.Date ��ʽת��Ϊ�ַ�����ʽ'yyyy-MM-dd HH:mm:ss a'(12Сʱ��)<br>
	 * ��Sat May 11 17:23:22 CST 2002 to '2002-05-11 05:23:22 ����'<br>
	 * @param time Date ����<br>
	 * @param x int ���������磺1<br>
	 * @return String �ַ���<br>
	 */
	public static String dateToString(Date time, int x) {
		SimpleDateFormat formatter;
		formatter = new SimpleDateFormat("yyyy-MM-dd KK:mm:ss a");
		String ctime = formatter.format(time);

		return ctime;
	}
	public static String dateToStringCustom(Date time,String format) {
		SimpleDateFormat formatter;
		formatter = new SimpleDateFormat(format);
		String ctime = formatter.format(time);

		return ctime;
	}

	/**
	 *ȡϵͳ��ǰʱ��:����ֵΪ������ʽ
	 * @return String
	 */
	public static String Nowyymmddhhmmss() {
		String dd = dateToString(new Date());
		dd = dd.substring(2, 4) + dd.substring(5, 7) + dd.substring(8, 10) +
		dd.substring(11, 13) + dd.substring(14, 16) + dd.substring(17, 19);
		return dd;
	}

	/**
	 *ȡϵͳ��ǰʱ��:����ֵֻΪ������ʽ
	 * @return String
	 */
	public static String Now() {
		return dateToString(new Date());
	}

	/**
	 *ȡϵͳ��ǰʱ��:����ֵֻΪ������ʽ
	 *@param hour Ϊ��������
	 *@return String
	 */
	public static String Now(int hour) {
		return dateToString(new Date(), hour);
	}
	/**
	 *ȡϵͳ��ǰʱ��:����ֵֻΪ������ʽ
	 *@return String
	 */
	public static String NowCustom(String format) {
		return dateToStringCustom(new Date(),format);
	}


	/**
	 *ȡϵͳ��ǰʱ��:����ֵֻΪ������ʽ
	 *@return String
	 */
	public static String getYYYY_MM_DD() {
		return dateToString(new Date()).substring(0, 10);

	}

	/**
	 *ȡϵͳ��ǰʱ��:����ֵֻΪ������ʽ
	 *@return String
	 */
	public static String getYYYYMMDD() {
		String L_curDate = Util.getYYYY_MM_DD();
		String L_curDate2 = L_curDate.substring(0, 4) +
		L_curDate.substring(5, 7) +
		L_curDate.substring(8, 10);
		return L_curDate2;
	}
	/**
	 *ȡϵͳ��ǰʱ��:����ֵֻΪ������ʽ
	 *@return String
	 */
	public static String getYYYY() {
		String L_curDate = Util.getYYYY_MM_DD();
		String L_curDate2 = L_curDate.substring(0, 4) ;       
		return L_curDate2;
	}
	/**
	 *ȡϵͳ��ǰʱ��:����ֵֻΪ������ʽ
	 *@return String
	 */
	public static String getYYMMDD() {
		String L_curDate = Util.getYYYY_MM_DD();
		String L_curDate2 = L_curDate.substring(2, 4) +
		L_curDate.substring(5, 7) +
		L_curDate.substring(8, 10);
		return L_curDate2;
	}

	/**
	 * �����ڽ�����Ӳ���
	 * @param date �����ַ�����ʽΪyyyy-mm-dd
	 * @param addNumber Ҫ���ӵ�����
	 * @return String ��ʽyyyy-mm-dd
	 */
	public static String getDateAdd(String date, int addNumber) {
		String returnStr = "";
		StringTokenizer token = new StringTokenizer(date, "-");
		int num = token.countTokens();
		if (num == 3) {
			int year;
			int month;
			int day;
			year = Integer.parseInt(token.nextToken());
			month = Integer.parseInt(token.nextToken());
			day = Integer.parseInt(token.nextToken());
			SimpleDateFormat formatter;
			formatter = new SimpleDateFormat("yyyy-MM-dd");
			Calendar calen = Calendar.getInstance();
			calen.set(year, month - 1, day);
			calen.add(5, addNumber); //5�������ڣ�1�����꣬2������
			returnStr = formatter.format(calen.getTime());
		} else {
			returnStr = date;
		}
		return returnStr;
	}
	/**
	 * ��Сʱ������Ӳ���
	 * @param date �����ַ�����ʽΪyyyy-mm-dd
	 * @param addNumber Ҫ���ӵ�Сʱ��
	 * @return String ��ʽyyyy-mm-dd
	 */
	public static String getHourAdd(int addNumber) {
		String returnStr = "";
		SimpleDateFormat forma=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date dd=new Date();
		Calendar g=Calendar.getInstance();
		g.setTime(dd);
		g.add(Calendar.HOUR,addNumber);
		returnStr=forma.format(g.getTime());
		return returnStr;
	}

	/**
	 *��ú��ֵļ�ƴ�� wxx
	 *@return String
	 */
	/*public  static String getSimpleSpell(String name){
        String ls_return,ls_jp;
        String ls_name,ls_temp;
        //���⴦��
        if ((name==null) || (name.trim().length()==0))  return "";
        //��ʼ������
        ls_return ="";
        ls_name = name;
        ls_jp="";
        ls_temp="";
        char  chatt;
        int itt=0;
        cDataControl cdcon=new cDataControl();//������
        for ( int i=0;i<ls_name.length();i++)
        {
          ls_temp=ls_name.substring(0,1);//
          chatt=ls_temp.charAt(0);
          itt=chatt;
          if (ls_name.length()>2){
          ls_name=ls_name.substring(1,ls_name.length());}//
          if (ls_temp==null) ls_temp ="";
           if (itt<128 ){  //С��128�������ĺ�����>128��������
             ls_jp = ls_temp;
           }else  if ( itt>128 ){
                 //�Ӽ�ƴ���л�ü�ƴ��
     ls_temp=pub.ViewControl.CharControl.Util.Gb2312toISO(ls_temp);
           ls_jp=cdcon.GetFirfield("set rowcount 0 select jp from dict where name='"+ls_temp+"'");
           if (ls_jp==null) {ls_jp="";}
         }
         ls_return = ls_return+ls_jp;
        }
        cdcon.ReturnConn();//�ͷ�����
        return ls_return;
      }*/
	/**
	 *��ú��ֵļ�ƴ�� wxx
	 *@return String
	 */
	/*
     public  static String getSimpleSpellold(String name){
        String ls_return,ls_jp;
        String ls_name,ls_temp,ls_hz;
        int   ll_len;
        boolean lb_hz;

        //���⴦��
        if ((name==null) || (name.trim().length()==0))  return "";
        //��ʼ������
        ls_return ="";
        lb_hz = false;
        ls_name = name;
        ls_hz="";
        ls_jp="";
        cDataControl cdcon=new cDataControl();//������
        //���ɼ�ƴ
        for (ll_len = 1;ll_len<name.length();)
        {        //�õ�����
          ls_temp = ls_name.substring(1,1);
           if (ls_temp==null) ls_temp ="";
              ls_name = ls_name.substring(2,ls_name.length());
              //��������ж��Ƿ����128
     if (( Integer.parseInt(ls_temp.getBytes().toString())>128 )&& (lb_hz==false)){
                lb_hz = true;
                ls_hz = ls_temp;
                ls_jp ="";
              }
              else if (( Integer.parseInt(ls_temp.getBytes().toString())>128 )&& (lb_hz==true)){
                ls_hz = ls_hz + ls_temp;
                 //�Ӽ�ƴ���л�ü�ƴ��
     ls_jp=cdcon.GetFirfield("select jp from dict where name='"+ls_hz+"'");
                 if (ls_jp==null) {ls_jp="";}
                 lb_hz = false;
              }else{
                lb_hz = false;
                ls_jp = ls_temp;
              }
             ls_return = ls_return+ls_jp;
        }
        cdcon.ReturnConn();//�ͷ�����
        return ls_return;
      }

     /**
	 *��ò�������������ż�� wxx
	 *����0 ����ż�� ��-1���� ����
	 */
	public static int isOddorEven(int iint) {
		int itmp = 0;
		try {
			itmp = iint % 2;
			if (itmp == 1) {
				itmp = -1; //����
			}
			if (itmp == 0) {
				itmp = 0; //ż��
			}
		} catch (Exception e) {
			itmp = -1;
		}
		return itmp;
	}

	/*************************************/
	//���ܣ�ת��Ϊhtml�����������ݿ�
	//���������ַ����е�
	public static String HtmlToDB(String s) {
		s = Replace(s, "&", "&amp;");
		s = Replace(s, "\n", "<br>");
		s = Replace(s, "<", "&lt;");
		s = Replace(s, ">", "&gt;");
		s = Replace(s, "\t", "    ");
		s = Replace(s, "\r\n", "\n");
		s = Replace(s, " ", "&nbsp;");
		s=Replace(s, "'", "&single_qu");
		return s;
	}

	//���ܣ������ݿ��е�encode���Ĵ��� ��� ��td��ʽ�����
	//������
	public static String DBToHtml(String s) {
		s = Replace(s, "&amp", "&;");
		s = Replace(s, "&lt;", "<");
		s = Replace(s, "&gt;", ">");
		s = Replace(s, "    ", "\t");
		s = Replace(s, "\n", "\r\n");
		s = Replace(s, "<br>", "<br>");
		s = Replace(s, " &nbsp;", " &nbsp; ");
		s=Replace(s, "&single_qu", "'");
		return s;
	}

	//���ܣ��޸���ʾʱ�����ݿ��е�encode���Ĵ��� ��� ��ʱ�Ƕ����ı���
	//������
	public static String HtmlWriteMX(String s) {
		s = Replace(s, "&amp", "&;");
		s = Replace(s, "&lt;", "<");
		s = Replace(s, "&gt;", ">");
		s = Replace(s, "    ", "\t");
		s = Replace(s, "\n", "\r\n");
		s = Replace(s, "<br>", "\n");
		s = Replace(s, "&nbsp;", " ");
		s=Replace(s, "&single_qu", "'");
		return s;
	}

	public static String InvertedCommaReplaceToDB(String s) {
		s=Replace(s, "'", "''");
		return s;
	}

	public static String Replace(
			String source,
			String oldString,
			String newString) {
		if (source == null) {
			return null;
		}
		StringBuffer output = new StringBuffer();
		int lengOfsource = source.length();
		int lengOfold = oldString.length();
		int posStart;
		int pos;
		for (posStart = 0; (pos = source.indexOf(oldString, posStart)) >= 0;
		posStart = pos + lengOfold) {
			output.append(source.substring(posStart, pos));
			output.append(newString);
		}

		if (posStart < lengOfsource) {
			output.append(source.substring(posStart));
		}
		return output.toString();
	}

	/*�����漴�ַ���*/
	public static String ProduceStr(int strLen) {
		if (strLen < 1) {
			return null;
		}
		if (strLen > 50) {
			strLen = 50;
		}
		String Vchar =
			"0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUWXYZ";
		int Vlength = Vchar.length();
		char[] rchars = new char[strLen];
		for (int i = 0; i < strLen; i++) {
			rchars[i] = Vchar.charAt((int) (Math.random() * Vlength));
		}
		return String.valueOf(rchars);
	}

	/*
	 *�ַ�������,�����ַ���Ҫ�����ַ���ǰ���ж��ٸ��ַ�
	 *ԭ�ַ���str
	 *Ҫ���ҵ��ַ�strfrom
	 *ԭ�ַ����г��ֵڼ���ifrom
	 */
	public static int formstr(String str, String strfrom, int ifrom) {
		int from = 0;
		int strfromlen = strfrom.length();
		for (int i = 0; i < ifrom; i++) {
			if (str.indexOf(strfrom, from) != -1) {
				from = str.indexOf(strfrom, from) + strfromlen;
			}
		}
		return from;
	}

	/*
	 *���ص�ǰ�����Ǳ��µĵڼ���
	 */
	public static String getWeek() {
		String week = "";
		Calendar calen = Calendar.getInstance();
		week=String.valueOf(calen.get(Calendar.WEEK_OF_MONTH));
		return week;
	}

	/*���ĳһ�����Ƿ���SortedMap����ĺ���*/
	public boolean CheckSortedMap(Object obj){
		if(obj instanceof SortedMap){
			return true;
		}
		return false;
	}

	/*���ĳһ�����Ƿ���List����ĺ���*/
	public boolean CheckList(Object obj){
		if(obj instanceof List){
			return true;
		}
		return false;
	}

	/*���ĳһ�����Ƿ���Map����ĺ���*/
	public boolean CheckMap(Object obj){
		if(obj instanceof Map){
			return true;
		}
		return false;
	}
	/**
	 *���ܣ���url��ַת�ݽ�����ֵ����ת��(url ת�� ����)*/
	public static String transUrlToData(String str){
		String temp=str;
		temp=replace(temp,"%2F","/");
		temp=replace(temp,"%26","&");
		temp=replace(temp,"%3F","?");
		temp=replace(temp,"%40","@");
		temp=replace(temp,"%23","#");
		temp=replace(temp,"%3B",";");
		temp=replace(temp,"%24","$");
		temp=replace(temp,"%2B","+");
		temp=replace(temp,"%3D","=");
		temp=replace(temp,"%25","%");
		return temp;
	}

	/**
	 *���ܣ���url��ַת�ݽ�����ֵ����ת��(���� ת�� url)
	 */
	public static String transDataToUrl(String str){
		String temp=str;
		temp=replace(temp,"/","%2F");
		temp=replace(temp,"&","%26");
		temp=replace(temp,"?","%3F");
		temp=replace(temp,"@","%40");
		temp=replace(temp,"#","%23");
		temp=replace(temp,";","%3B");
		temp=replace(temp,"$","%24");
		temp=replace(temp,"+","%2B");
		temp=replace(temp,"=","%3D");
		temp=replace(temp,"%","%25");
		return temp;
	}

	/**�ж�����*/
	public static boolean checkInt(String str){
		if(str!=null && str.matches("[\\d]+")){
			return true;
		}
		return false;
	}

	/**
	 * �����ڽ�����Ӳ���(���²���)
	 * @param date �����ַ�����ʽΪyyyy-mm-dd
	 * @param addNumber Ҫ��
	 * @return String ��ʽyyyy-mm-dd
	 */
	public static String getDateMonthAdd(String date, int addNumber) {
		String returnStr = "";
		StringTokenizer token = new StringTokenizer(date, "-");
		int num = token.countTokens();
		if (num == 3) {
			int year;
			int month;
			int day;
			year = Integer.parseInt(token.nextToken());
			month = Integer.parseInt(token.nextToken());
			day = Integer.parseInt(token.nextToken());
			SimpleDateFormat formatter;
			formatter = new SimpleDateFormat("yyyy-MM-dd");
			Calendar calen = Calendar.getInstance();
			calen.set(year, month - 1, day);
			calen.add(2, addNumber); //5�������ڣ�1�����꣬2������
			returnStr = formatter.format(calen.getTime());
		} else {
			returnStr = date;
		}
		return returnStr;
	}	
	/**
	 * �ǿ�У��
	 * @param object
	 * @return boolean
	 */
	public static boolean isNullOrEmpty(Object object){
		if(object==null||"".equals(object.toString().trim())){
			return true;
		}
		return false;
	}
	/**
	 * @param obj �ַ����Դ�
	 * @param subLength ��ȡ����
	 * @return ����ַ�������С�ڵ��� subLength �򷵻�ԭ�ַ��� ���򷵻ؽ�ȡ���ַ�����...
	 */
	public static String subString(Object obj,int subLength){
		if(obj==null){
			return "";
		}
		String temp = obj.toString();
		int length= temp.length();
		if(subLength>=length){
			return temp;
		}
		return temp.substring(0, subLength)+"����";
	}
	public static void printResult(HttpServletResponse response,String content,String contentType,boolean isClose){
		try {
			response.setContentType(contentType);
			response.getWriter().write(content);
			if(isClose){
				response.getWriter().flush();
				response.getWriter().close();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void printResult(HttpServletResponse response,String content,boolean isClose){
		try {
			response.setContentType("text/html;charset=utf-8");
			response.getWriter().write(content);
			if(isClose){
				response.getWriter().flush();
				response.getWriter().close();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void printResult(HttpServletResponse response,String content){
		try {
			response.setContentType("text/html;charset=utf-8");
			response.getWriter().write(content);
			response.getWriter().flush();
			response.getWriter().close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static String getCamleToLower(String name){
		return name.replaceFirst(String.valueOf(name.charAt(0)), String.valueOf((char)(name.charAt(0)+32)));
	}
	public static String getCamle(String name){
		name=name.toLowerCase();
		String replace=getPropertyResourceBundle("template").getString("template.replace.tablename");
		if(replace!=null){
			replace =replace.toLowerCase();
			String[] replaceTemp=replace.split("\\|");
			for(String temp :replaceTemp){
				String[] temp1=temp.split(",");
				if(temp1.length>1){
					if(!"_".equals(temp1[1])){
						name=name.replace(temp1[0], temp1[1]);
					}
				}else{
					if(!"_".equals(temp1[0])){
						name=name.replace(temp1[0], "");
					}
				}
			}
		}
		StringBuffer res = new StringBuffer();
		String[] temp = name.split("_");
		for(String temp1:temp){
			try {
				res.append(temp1.replaceFirst(String.valueOf(temp1.charAt(0)), String.valueOf((char)(temp1.charAt(0)-32))));
			} catch (Exception e) {
				System.out.println(temp1); 
				e.printStackTrace();
			}
		}
		return res.toString();
	}
	/**
	 * ��unicodeת�ɺ���
	 * @param utfString
	 * @return 
	 */
	public static String unicodeToChinses(String utfString){ 
		if(utfString==null){
			return "";
		}
		StringBuilder sb = new StringBuilder();  
		Pattern pattern = Pattern.compile("(\\\\u(\\p{XDigit}{4}))");    
		Matcher matcher = pattern.matcher(utfString);
		char ch;
		while (matcher.find()) {
			ch = (char) Integer.parseInt(matcher.group(2), 16);
			utfString = utfString.replace(matcher.group(1), ch + "");    
		}
		return utfString;
	} 
	private static final char[] hexDigit = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A',
		'B', 'C', 'D', 'E', 'F' };

	private static char toHex(int nibble) {
		return hexDigit[(nibble & 0xF)];
	}

	/**
	 * ���ַ�������� Unicode ��ʽ���ַ���. �� "��" to "\u9EC4"
	 * @param theString
	 *        ��ת����Unicode������ַ�����
	 * @param escapeSpace
	 *        �Ƿ���Կո�Ϊtrueʱ�ڿո�����Ƿ�Ӹ���б�ܡ�
	 * @return ����ת����Unicode������ַ�����
	 */

	public static String chinsesToUnicode(String theString, boolean escapeSpace) {
		int len = theString.length();
		int bufLen = len * 2;
		if (bufLen < 0) {
			bufLen = Integer.MAX_VALUE;
		}
		StringBuffer outBuffer = new StringBuffer(bufLen);
		for (int x = 0; x < len; x++) {
			char aChar = theString.charAt(x);
			// Handle common case first, selecting largest block that
			// avoids the specials below
			if ((aChar > 61) && (aChar < 127)) {
				if (aChar == '\\') {
					outBuffer.append('\\');
					outBuffer.append('\\');
					continue;
				}
				outBuffer.append(aChar);
				continue;
			}
			switch (aChar) {
			case ' ':
				if (x == 0 || escapeSpace) outBuffer.append('\\');
				outBuffer.append(' ');
				break;
			case '\t':
				outBuffer.append('\\');
				outBuffer.append('t');
				break;
			case '\n':
				outBuffer.append('\\');
				outBuffer.append('n');
				break;
			case '\r':
				outBuffer.append('\\');
				outBuffer.append('r');
				break;
			case '\f':
				outBuffer.append('\\');
				outBuffer.append('f');
				break;
			case '=': // Fall through
			case ':': // Fall through
			case '#': // Fall through
			case '!':
				outBuffer.append('\\');
				outBuffer.append(aChar);
				break;
			default:
				if ((aChar < 0x0020) || (aChar > 0x007e)) {
					// ÿ��unicode��16λ��ÿ��λ��Ӧ��16���ƴӸ�λ���浽��λ
					outBuffer.append('\\');
					outBuffer.append('u');
					outBuffer.append(toHex((aChar >> 12) & 0xF));
					outBuffer.append(toHex((aChar >> 8) & 0xF));
					outBuffer.append(toHex((aChar >> 4) & 0xF));
					outBuffer.append(toHex(aChar & 0xF));
				} else {
					outBuffer.append(aChar);
				}
			}
		}
		return outBuffer.toString();
	}
	public static String parseListToJson(List list){
		if(list==null||list.size()==0){
			return "[]";
		}
		StringBuffer sb = new StringBuffer("[");
		for(int i=0;i<list.size();i++){
			Object obj = list.get(i);
			if(i>0){
				sb.append(",");
			}
			int j=0;
			if (obj instanceof java.util.Map) {
				Map map = (Map) obj;
				sb.append("{");
				Iterator it = map.keySet().iterator();
				while (it.hasNext()) {
					if(j>0){
						sb.append(",");
					}
					String key = it.next().toString();
					sb.append(key+":\"");
					sb.append(map.get(key));
					sb.append("\"");
					j++;
				}
				sb.append("}");
			}else if (obj instanceof java.util.List) {
				List listtemp = (List) obj;
				sb.append("[");
				Iterator it = listtemp.iterator();
				while (it.hasNext()) {
					if(j>0){
						sb.append(",");
					}
					String key = it.next().toString();
					sb.append("\"");
					sb.append(key);
					sb.append("\"");
					j++;
				}
				sb.append("]");
			}
		}
		sb.append("]");
		return sb.toString();
	}
	public static String parseMapToJson(Map map){
		if(map==null){
			return "{}";
		}
		StringBuffer sb = new StringBuffer("{");
		int j=0;
		Iterator it = map.keySet().iterator();
		while (it.hasNext()) {
			if(j>0){
				sb.append(",");
			}
			String key = it.next().toString();
			sb.append(key+":\"");
			sb.append(map.get(key));
			sb.append("\"");
			j++;
		}
		sb.append("}");
		return sb.toString();
	}
	public static boolean isChinese(char c) {  
		Character.UnicodeBlock ub = Character.UnicodeBlock.of(c);  
		if (ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS  
				|| ub == Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS  
				|| ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A  
				|| ub == Character.UnicodeBlock.GENERAL_PUNCTUATION  
				|| ub == Character.UnicodeBlock.CJK_SYMBOLS_AND_PUNCTUATION  
				|| ub == Character.UnicodeBlock.HALFWIDTH_AND_FULLWIDTH_FORMS) {  
			return true;  
		}  
		return false;  
	}  

	/**
	 * �ж��Ƿ����� ����true˵������
	 * @param strName
	 * @return 
	 */
	public static boolean isMessyCode(String strName) {  
		Pattern p = Pattern.compile("\\s*|\t*|\r*|\n*");  
		Matcher m = p.matcher(strName);  
		String after = m.replaceAll("");  
		String temp = after.replaceAll("\\p{P}", "");  
		char[] ch = temp.trim().toCharArray();  
		float chLength = ch.length;  
		float count = 0;  
		for (int i = 0; i < ch.length; i++) {  
			char c = ch[i];  
			if (!Character.isLetterOrDigit(c)) {  

				if (!isChinese(c)) {  
					count = count + 1;  
					System.out.print(c);  
				}  
			}  
		}  
		float result = count / chLength;  
		if (result > 0.4) {  
			return true;  
		} else {  
			return false;  
		}  

	}
	
	/**
	 * @param ��listת����String����
	 * @return
	 */
	public static String[] parseListToArray(List list){
		if(list==null){
			return null;
		}
		String[] str = new String[list.size()];
		for (int i = 0; i < list.size(); i++) {
			str[i]=(String) list.get(i);
		}
		return str;
	}
	/** 
	 * ��ָ��URL����GET���������� 
	 * @param url ���������URL 
	 * @param params ����������������Ӧ����name1=value1&name2=value2����ʽ�� 
	 * @return URL������Զ����Դ����Ӧ     */ 
	public static String sendGet(String url, String params,String encode) { 
		String result = ""; 
		BufferedReader in = null; 
		try { 
			String urlName = url + "?" + params; 
			//����URL
			URL realUrl = new URL(urlName); 
			// �򿪺�URL֮������� 
			URLConnection conn = realUrl.openConnection(); 
			// ����ͨ�õ��������� 
			conn.setRequestProperty("accept", "*/*"); 
			conn.setRequestProperty("connection", "Keep-Alive"); 
			conn.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)"); 
			// ����ʵ�ʵ����� 
			conn.connect(); 
			// ��ȡ������Ӧͷ�ֶ� 
			Map<String, List<String>> map = conn.getHeaderFields(); 
			// �������е���Ӧͷ�ֶ� 
			for (String key : map.keySet()) { 
				//                 System.out.println(key + "--->" + map.get(key)); 
			} 
			// ����BufferedReader����������ȡURL����Ӧ 
			in = new BufferedReader(new InputStreamReader(conn.getInputStream(),encode)); 
			String line; 
			while ((line = in.readLine()) != null) { 
				result += line; 
			} 
		} catch (Exception e) { 
			e.printStackTrace();
		} 
		// ʹ��finally�����ر������� 
		finally { 
			try { 
				if (in != null) { 
					in.close(); 
				} 
			} catch (IOException ex) { 
				ex.printStackTrace(); 
			} 
		} 
		return result; 
	} 
	/** 
	 * ��ָ��URL����POST���������� 
	 *  
	 * @param url 
	 *            ���������URL 
	 * @param params 
	 *            ����������������Ӧ����name1=value1&name2=value2����ʽ�� 
	 * @return URL������Զ����Դ����Ӧ 
	 */ 
	public static String sendPost(String url, String params) { 
		PrintWriter out = null; 
		BufferedReader in = null; 
		String result = ""; 
		try { 
			URL realUrl = new URL(url); 
			// �򿪺�URL֮������� 
			URLConnection conn = realUrl.openConnection(); 
			// ����ͨ�õ��������� 
			conn.setRequestProperty("accept", "*/*"); 
			conn.setRequestProperty("connection", "Keep-Alive"); 
			conn.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)"); 
			// ����POST������������������� 
			conn.setDoOutput(true); 
			conn.setDoInput(true); 
			// ��ȡURLConnection�����Ӧ������� 
			out = new PrintWriter(conn.getOutputStream()); 
			// ����������� 
			out.print(params); 
			// flush������Ļ��� 
			out.flush();
			// ����BufferedReader����������ȡURL����Ӧ 
			in = new BufferedReader(new InputStreamReader(conn.getInputStream())); 
			String line; 
			while ((line = in.readLine()) != null) { 
				result += "\n" + line; 
			} 
		} catch (Exception e) { 
			e.printStackTrace();
		} 
		// ʹ��finally�����ر�������������� 
		finally { 
			try { 
				if (out != null) { 
					out.close(); 
				} 
				if (in != null) { 
					in.close(); 
				} 
			} catch (IOException ex) { 
				ex.printStackTrace();
			} 
		} 
		return result; 
	} 
	/**
	 * @param Exception
	 * @return ���쳣��Ϣ�ŵ��ַ�����
	 */
	public static String getStackTraceDes(Exception ex){
		StackTraceElement[] elements = ex.getStackTrace();
		if (elements==null) {
			return "";
		}
		StringBuffer sb = new StringBuffer();
		sb.append(ex.getMessage()+"\r\n");
		int length = elements.length;
		for (int i = 0; i <length ; i++) {
			StackTraceElement element = elements[i];
			sb.append(element.getClassName()+"��"+element.getMethodName()+"��"+element.getLineNumber()+"\r\n");
		}
		return sb.toString();
	}
	public static void main(String[] args) {
		System.out.println(isMessyCode("���")); 
	}


}
