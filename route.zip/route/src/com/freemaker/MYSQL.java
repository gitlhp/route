package com.freemaker;

public class MYSQL implements DataBaseTypeRelation {
	static{
		TypeRelation.put("varchar", "java.lang.String");
		TypeRelation.put("char", "java.lang.String");
		TypeRelation.put("bigint", "int");
		TypeRelation.put("int", "int");
		TypeRelation.put("datetime", "java.lang.String");
		TypeRelation.put("float", "float");
		TypeRelation.put("decimal", "long");
		TypeRelation.put("longblob", "byte[]");
	}
	public String getCols(String tablename,String userName) {
		return "SELECT t.column_name COLNAME,t.data_type TYPE,t.column_comment TITLE from INFORMATION_SCHEMA.COLUMNS t where TABLE_SCHEMA='"+userName+"' and TABLE_NAME='"+tablename+"'";
	}

	public String getTables(String userName) {
//		return "SELECT table_name FROM dba_tables where owner='"+userName+"'";
		return "SELECT t.table_name CLASSNAME,REPLACE(TABLE_COMMENT,'; InnoDB free: 11264 kB','') TITLE from INFORMATION_SCHEMA.TABLES t where TABLE_SCHEMA='"+userName+"' and t.table_name like 'tbl_base_link%' ";
	}
	public String getPk(String tablename,String userName) {
		return " select t.TABLE_NAME CLASSNAME,c.COLUMN_NAME COLNAME from INFORMATION_SCHEMA.TABLE_CONSTRAINTS  t, INFORMATION_SCHEMA.KEY_COLUMN_USAGE  c "+ 
        "where t.TABLE_NAME = c.TABLE_NAME   AND t.TABLE_SCHEMA = '"+userName+"' AND t.CONSTRAINT_TYPE = 'PRIMARY KEY' and t.TABLE_NAME ='"+tablename+"'";
	}
	public String getFk(String tablename,String userName) {
		return " select t.TABLE_NAME CLASSNAME,c.COLUMN_NAME COLNAME from INFORMATION_SCHEMA.TABLE_CONSTRAINTS  t, INFORMATION_SCHEMA.KEY_COLUMN_USAGE  c "+ 
        "where t.TABLE_NAME = c.TABLE_NAME   AND t.TABLE_SCHEMA = '"+userName+"' AND t.CONSTRAINT_TYPE = 'FOREIGN KEY' and t.TABLE_NAME ='"+tablename+"'";
	}
	public static void main(String[] args) {
		DataBaseTypeRelation o = new MYSQL() ;
		System.out.println(o.TypeRelation.get("VARCHAR2"));
	}
}
