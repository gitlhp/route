package com.freemaker;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.util.PageModel;
import com.util.Util;

public class OperDao extends DB {
	private static String showtype="t";
	private static String checktype="isnotnull";
	public  void init(){
		//�����Լ�ϵͳ�ı�
		String where=" and s.table_name not in('TABLES','SQLS','CODES','COLTYPE','DEPT','FILES','USERS','COLS','NOTIE') ";
		String sql="delete from tables";
		this.executeSql(sql);
		sql="delete from cols";
		this.executeSql(sql);
		//��������������
		sql=" PURGE RECYCLEBIN ";
		this.executeSql(sql);
		System.out.println("*************************��ʼ������ tables**********************************");
		//��ʼ������ tables
		sql = "insert into tables(tableen,tablech,remark) SELECT t.table_name classname,s.comments,'' title from user_tab_comments s,user_tables t where s.table_name=t.table_name "+where;
		this.executeSql(sql);
		System.out.println("*************************��ʼ���е�  cols**********************************");
		//��ʼ���е�  cols
		sql="insert into cols(TABLENAME,COL,COLNAME,DATATYPE,num) SELECT c.table_name,c.column_name colname, s.comments title, c.data_type,rownum type FROM user_col_comments s, USER_TAB_COLS c where c.table_name = s.table_name  and s.column_name = c.column_name "+where+" order by c.table_name";
		this.executeSql(sql);
		System.out.println("*************************�������ó�ʼ���е�����**********************************");
		//�������ó�ʼ���е�����
		sql="SELECT c.table_name tablename,c.column_name colname, s.comments title FROM user_col_comments s, USER_TAB_COLS c where c.table_name = s.table_name and s.column_name = c.column_name "+where+" order by c.table_name";
		List<Map<String,Object>> list = this.query(sql);
		List<Map<String,Object>> checktypelist = this.query("select code from coltype c where c.codetype='checktype'");
		List<Map<String,Object>> showtypelist = this.query("select code from coltype c where c.codetype='showtype'");
		List<String> sqls = new ArrayList<String>();
		if (list!=null) {
			for (Iterator iter = list.iterator(); iter.hasNext();) {
				Map<String,Object> map = (Map<String,Object>) iter.next();
				//colname�������з��������� ��һ����Ϊ���⣬�ڶ�����Ϊչ�ֵ����ԣ�������Ϊ��֤�ķ�ʽ
				String colname = map.get("colname")==null?"":map.get("colname").toString();
				String tablename = map.get("tablename")==null?"":map.get("tablename").toString();
				String title = map.get("title")==null?"":map.get("title").toString();
				if(!"".equals(title)){
					String[] coltype=title.split(",");
					int length = coltype.length;
					if(length==1){
						sqls.add("UPDATE cols SET showtype='"+showtype+"',checktype='"+checktype+"' where TABLENAME='"+tablename+"' and COL='"+colname+"'");
					}else if(length==2){
						sqls.add("UPDATE cols SET COLNAME='"+coltype[0]+"',showtype='"+checkVal(showtypelist,coltype[1],showtype)+"',checktype='"+checktype+"' where TABLENAME='"+tablename+"' and COL='"+colname+"'");
					}else{
						sqls.add("UPDATE cols SET COLNAME='"+coltype[0]+"',showtype='"+checkVal(showtypelist,coltype[1],showtype)+"',checktype='"+checkVal(checktypelist,coltype[2],checktype)+"' where TABLENAME='"+tablename+"' and COL='"+colname+"'");
					}
				}
			}
			if(sqls.size()>0){
				this.batchSql(Util.parseListToArray(sqls));
			}
		}
		System.out.println("**************************����������**********************************");
		//��������
		sql=" select cu.table_name tablename,cu.column_name colname from user_cons_columns cu, user_constraints s " +
				"where cu.constraint_name = s.constraint_name and s.constraint_type = 'P' "+where;
		list = this.query(sql);
		if (list!=null) {
			sqls = new ArrayList<String>();
			for (Iterator iter = list.iterator(); iter.hasNext();) {
				Map<String,Object> map = (Map<String,Object>) iter.next();
				//colname�������з��������� ��һ����Ϊ���⣬�ڶ�����Ϊչ�ֵ����ԣ�������Ϊ��֤�ķ�ʽ
				String colname = map.get("colname")==null?"":map.get("colname").toString();
				String tablename = map.get("tablename")==null?"":map.get("tablename").toString();
				sqls.add("UPDATE cols SET pk='1' where TABLENAME='"+tablename+"' and COL='"+colname+"'");
			}
			if(sqls.size()>0){
				this.batchSql(Util.parseListToArray(sqls));
			}
		}
		System.out.println("**************************���������**********************************");
		//�������
		sql="  select cu.table_name classname,cu.column_name colname from user_cons_columns cu, user_constraints s " +
		"where cu.constraint_name = s.r_constraint_name and s.constraint_type = 'R'"+where;
		list = this.query(sql);
		if (list!=null) {
			sqls = new ArrayList<String>();
			for (Iterator iter = list.iterator(); iter.hasNext();) {
				Map<String,Object> map = (Map<String,Object>) iter.next();
				//colname�������з��������� ��һ����Ϊ���⣬�ڶ�����Ϊչ�ֵ����ԣ�������Ϊ��֤�ķ�ʽ
				String colname = map.get("colname")==null?"":map.get("colname").toString();
				String tablename = map.get("tablename")==null?"":map.get("tablename").toString();
				sqls.add("UPDATE cols SET fk='1' where TABLENAME='"+tablename+"' and COL='"+colname+"'");
			}
			if(sqls.size()>0){
				this.batchSql(Util.parseListToArray(sqls));
			}
		}
		System.out.println("**************************��ʼ�����**********************************");
	}
	public int addCols(HttpServletRequest req){
		String colname=req.getParameter("colname")==null?"":req.getParameter("colname");
		String pk=req.getParameter("pk")==null?"":req.getParameter("pk");
		String fk=req.getParameter("fk")==null?"":req.getParameter("fk");
		String datatype=req.getParameter("datatype")==null?"":req.getParameter("datatype");
		String showtype=req.getParameter("showtype")==null?"":req.getParameter("showtype");
		String isreadonly=req.getParameter("isreadonly")==null?"":req.getParameter("isreadonly");
		String checktype=req.getParameter("checktype")==null?"":req.getParameter("checktype");
		String sqlid=req.getParameter("sqlid")==null?"":req.getParameter("sqlid");
		String style=req.getParameter("style")==null?"":req.getParameter("style");
		String event=req.getParameter("event")==null?"":req.getParameter("event");
		String other=req.getParameter("other")==null?"":req.getParameter("other");
		String changeid=req.getParameter("changeid")==null?"":req.getParameter("changeid");
		String changesqlid=req.getParameter("changesqlid")==null?"":req.getParameter("changesqlid");
		String sql ="insert into COLS("+
        		"COLNAME"+
        		",PK"+
        		",FK"+
        		",DATATYPE"+
        		",SHOWTYPE"+
        		",ISREADONLY"+
        		",CHECKTYPE"+
        		",SQLID"+
        		",STYLE"+
        		",EVENT"+
        		",OTHER"+
        		",CHANGEID"+
        		",CHANGESQLID"+
        	") values("+
        		"'"+colname+"'"+
        	        		",'"+pk+"'"+
        	        		",'"+fk+"'"+
        	        		",'"+datatype+"'"+
        	        		",'"+showtype+"'"+
        	        		",'"+isreadonly+"'"+
        	        		",'"+checktype+"'"+
        	        		",'"+sqlid+"'"+
        	        		",'"+style+"'"+
        	        		",'"+event+"'"+
        	        		",'"+other+"'"+
        	        		",'"+changeid+"'"+
        	        		",'"+changesqlid+"'"+
        	")";
        	DB db = new DB();
        	return db.executeSql(sql);	
	}
	public int delCols(HttpServletRequest req){
         String tablename=req.getParameter("tablename");
         String col=req.getParameter("col");
		String sql ="delete from COLS where 1=1 "+
    		" and tablename ='"+tablename+"'"+
    		" and col ='"+col+"'"+
    	"";
    	DB db = new DB();
    	return db.executeSql(sql);	
	}
	public int updCols(HttpServletRequest req){
		String colname=req.getParameter("colname")==null?"":req.getParameter("colname");
		String pk=req.getParameter("pk")==null?"":req.getParameter("pk");
		String fk=req.getParameter("fk")==null?"":req.getParameter("fk");
		String datatype=req.getParameter("datatype")==null?"":req.getParameter("datatype");
		String showtype=req.getParameter("showtype")==null?"":req.getParameter("showtype");
		String isreadonly=req.getParameter("isreadonly")==null?"":req.getParameter("isreadonly");
		String checktype=req.getParameter("checktype")==null?"":req.getParameter("checktype");
		String sqlid=req.getParameter("sqlid")==null?"":req.getParameter("sqlid");
		String style=req.getParameter("style")==null?"":req.getParameter("style");
		String event=req.getParameter("event")==null?"":req.getParameter("event");
		String other=req.getParameter("other")==null?"":req.getParameter("other");
		String changeid=req.getParameter("changeid")==null?"":req.getParameter("changeid");
		String changesqlid=req.getParameter("changesqlid")==null?"":req.getParameter("changesqlid");
        String tablename=req.getParameter("tablename");
        String col=req.getParameter("col");
		String sql ="update COLS set "+
        		"COLNAME='"+colname+"'"+
        		",PK='"+pk+"'"+
        		",FK='"+fk+"'"+
        		",DATATYPE='"+datatype+"'"+
        		",SHOWTYPE='"+showtype+"'"+
        		",ISREADONLY='"+isreadonly+"'"+
        		",CHECKTYPE='"+checktype+"'"+
        		",SQLID='"+sqlid+"'"+
        		",STYLE='"+style+"'"+
        		",EVENT='"+event+"'"+
        		",OTHER='"+other+"'"+
        		",CHANGEID='"+changeid+"'"+
        		",CHANGESQLID='"+changesqlid+"'"+
        	" where 1=1 "+
    		" and tablename ='"+tablename+"'"+
    		" and col ='"+col+"'"+
    	"";
        	DB db = new DB();
        	return db.executeSql(sql);	
	}
	public Map<String,Object> findColsById(HttpServletRequest req){
         String tablename=req.getParameter("tablename");
         String col=req.getParameter("col");
		String sql ="select * from COLS where 1=1 "+
    		" and tablename ='"+tablename+"'"+
    		" and col ='"+col+"'"+
    	"";
    	DB db = new DB();
    	Map<String,Object> map = null;
    	List<Map<String,Object>> list = db.query(sql);
    	if(list!=null&&list.size()>0){
    		map = list.get(0);
    	}
    	return map;	
	}
	
	
	public PageModel findColsByCondition(HttpServletRequest req){
		String colname=req.getParameter("colname")==null?"":req.getParameter("colname");
		req.setAttribute("colname", colname);
		String pk=req.getParameter("pk")==null?"":req.getParameter("pk");
		req.setAttribute("pk", pk);
		String fk=req.getParameter("fk")==null?"":req.getParameter("fk");
		req.setAttribute("fk", fk);
		String datatype=req.getParameter("datatype")==null?"":req.getParameter("datatype");
		req.setAttribute("datatype", datatype);
		String showtype=req.getParameter("showtype")==null?"":req.getParameter("showtype");
		req.setAttribute("showtype", showtype);
		String isreadonly=req.getParameter("isreadonly")==null?"":req.getParameter("isreadonly");
		req.setAttribute("isreadonly", isreadonly);
		String checktype=req.getParameter("checktype")==null?"":req.getParameter("checktype");
		req.setAttribute("checktype", checktype);
		String sqlid=req.getParameter("sqlid")==null?"":req.getParameter("sqlid");
		req.setAttribute("sqlid", sqlid);
		String style=req.getParameter("style")==null?"":req.getParameter("style");
		req.setAttribute("style", style);
		String event=req.getParameter("event")==null?"":req.getParameter("event");
		req.setAttribute("event", event);
		String other=req.getParameter("other")==null?"":req.getParameter("other");
		req.setAttribute("other", other);
		String changeid=req.getParameter("changeid")==null?"":req.getParameter("changeid");
		req.setAttribute("changeid", changeid);
		String changesqlid=req.getParameter("changesqlid")==null?"":req.getParameter("changesqlid");
		req.setAttribute("changesqlid", changesqlid);
         String tablename=req.getParameter("tablename");
         String col=req.getParameter("col");
		String sql ="";
		String where="";
		if(colname!=null&&!"".equals(colname)){
    		where+=" and COLNAME like '%"+colname+"%'";
		}
		if(pk!=null&&!"".equals(pk)){
    		where+=" and PK like '%"+pk+"%'";
		}
		if(fk!=null&&!"".equals(fk)){
    		where+=" and FK like '%"+fk+"%'";
		}
		if(datatype!=null&&!"".equals(datatype)){
    		where+=" and DATATYPE like '%"+datatype+"%'";
		}
		if(showtype!=null&&!"".equals(showtype)){
    		where+=" and SHOWTYPE like '%"+showtype+"%'";
		}
		if(isreadonly!=null&&!"".equals(isreadonly)){
    		where+=" and ISREADONLY like '%"+isreadonly+"%'";
		}
		if(checktype!=null&&!"".equals(checktype)){
    		where+=" and CHECKTYPE like '%"+checktype+"%'";
		}
		if(sqlid!=null&&!"".equals(sqlid)){
    		where+=" and SQLID like '%"+sqlid+"%'";
		}
		if(style!=null&&!"".equals(style)){
    		where+=" and STYLE like '%"+style+"%'";
		}
		if(event!=null&&!"".equals(event)){
    		where+=" and EVENT like '%"+event+"%'";
		}
		if(other!=null&&!"".equals(other)){
    		where+=" and OTHER like '%"+other+"%'";
		}
		if(changeid!=null&&!"".equals(changeid)){
    		where+=" and CHANGEID like '%"+changeid+"%'";
		}
		if(changesqlid!=null&&!"".equals(changesqlid)){
    		where+=" and CHANGESQLID like '%"+changesqlid+"%'";
		}
    	String countsql ="select count(*) from COLS where 1=1 "+where;
    	PageModel model = new PageModel();
		String tempPage = req.getParameter("currentPage");
		int currentPage = 1;
		try {
			currentPage = Integer.parseInt(tempPage);
		} catch (NumberFormatException e) {
			currentPage=1;
		}
		model.setCurrentPage(currentPage);
		String tempCount = req.getParameter("pageCount");
		int pageCount = 20;
		try {
			pageCount = Integer.parseInt(tempCount);
		} catch (NumberFormatException e) {
			pageCount=20;
		}
		model.setPageCount(pageCount);
		if("sqlserver".equals(DB.SQLTYPE)){
			if(currentPage==1){
				sql="select top "+pageCount+" * from COLS where 1=1 "+where+" order by  tablename  col  desc";
			}else{
				sql="select top "+pageCount+" * from COLS where 1=1 "+where+" and   tablename  col  " +
					"not in (select top (("+currentPage+"-1)*"+pageCount+")  tablename  col  from COLS where 1=1 "+where+" order by  tablename  col  desc) order by  tablename  col  desc";
			}
		}
    	DB db = new DB();
    	int count = Integer.parseInt(db.queryFirst(countsql));
    	model.setTotalCount(count);
    	if(count>0){
    		model.setRes(db.query(sql));
    	}
    	return model;	
	}
	public static String checkVal(List<Map<String,Object>> list,String str,String def){
		if(list==null|| list.size()==0){
			return def;
		}
		boolean bo = false;
		for (Iterator iter = list.iterator(); iter.hasNext();) {
			Map<String, Object> element = (Map<String, Object>) iter.next();
			if(element.values().contains(str)){
				bo = true;
				break;
			}
		}
		return bo?str:def;
	}
}
