package com.freemaker;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.PropertyResourceBundle;

import javax.servlet.http.HttpServletRequest;


import com.util.Util;

import freemarker.template.Configuration;
import freemarker.template.Template;

public class Create {
	/**
	 * TypeRelation ������ݿ��java�����ݹ�ϵӳ��  key������ݵ��������� val���java����������
	 * �����ݿ��LONG����java��long ��TypeRelation.put("LONG", "long");
	 */
	public static Map<String, String> TypeRelation = new HashMap<String, String>();
	static{
		TypeRelation.put("VARCHAR2", "java.lang.String");
		TypeRelation.put("CHAR", "java.lang.String");
		TypeRelation.put("NUMBER", "long");
		TypeRelation.put("DATE", "java.lang.String");
		TypeRelation.put("FLOAT", "float");
		TypeRelation.put("LONG", "long");
		TypeRelation.put("NVARCHAR2", "java.lang.String");
		TypeRelation.put("UROWID", "java.lang.String");
		TypeRelation.put("BLOB", "byte[]");
	}
	private static Configuration con = new Configuration();
	private static String directoryForTemplateLoading = null;
	private static String pageEncoding = null;
	private static PropertyResourceBundle bundle = Util.getPropertyResourceBundle("template");
	private static boolean rewirte=false;
	private static HttpServletRequest request = null;
	private static String path = "D:\\jsp\\route";
	public  void  init(HttpServletRequest request){
		this.request = request;
		try {
			
			String filePath = bundle.getString("template.templateLoaderPath").replaceAll("\\.", "/");
			String encoding = bundle.getString("template.defaultEncoding");
//			String tempDir = System.getProperty("user.dir")+"/src/"+filePath;
			String tempDir = path+"/src/"+filePath;
			con.setDirectoryForTemplateLoading(new File(tempDir));
			con.setEncoding(Locale.getDefault(), pageEncoding); 
			directoryForTemplateLoading=tempDir;
			pageEncoding=encoding;
			String temp =bundle.getString("template.rewriter");
			if("true".equals(temp)){
				rewirte = true;
			}
			writeFile();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public  void writeFile()throws Exception{
		File file = new File(directoryForTemplateLoading);
		FilenameFilter filter =new FilenameFilter() {
			public boolean accept(File dir, String name) {
				if(name.toLowerCase().endsWith(".ftl")&&!name.toUpperCase().equals("XMLPATH_TXT.FTL")){
					return true;
				}
				return false;
			}
		};
		File[] templates =file.listFiles(filter);
		templates = sort(templates);
		List<Map<String, Object>> allTable =  getTables();
		Map all =new HashMap();
		all.put("TABLES", allTable);
		System.out.println("��ʼ�����ļ�����"+templates.length+"��ģ�壬"+allTable.size()+"������");
		String webPath=bundle.getString("template.path");
		for(Map<String, Object> targetClazz:allTable ){
			List colSize=(List) targetClazz.get("NOPK");
			targetClazz.put("PATH", webPath);
			int tempsize=colSize.size()%2==0?colSize.size()/2:colSize.size()/2+1;
			targetClazz.put("HEIGHT", (tempsize*25+60));
			for(File f :templates){
				String fileName = f.getName();
				String tempFileName=fileName.substring(0, fileName.lastIndexOf("."));
				String[] fileType=tempFileName.split("_");
				if(fileType.length<2){
					throw new Exception("FileName: "+fileName+"  is wrong style.");
				}
				Template template =  con.getTemplate(fileName, pageEncoding);
				String sign="";//��������ļ��ǲ��Ǽ���ǰ׺����׺
				String before="";//��������ļ��ǲ��Ǽ���ǰ׺��ǰ׺
				String end="";//��������ļ��ǲ��Ǽ��Ϻ�׺����׺
				try {
					sign=bundle.getString("template."+fileType[1]+".sign");
				} catch (Exception e1) {
					sign="";
				}
				try {
					end=bundle.getString("template."+fileType[1]+".end");
				} catch (Exception e1) {
					end="";
				}
				try {
					before=bundle.getString("template."+fileType[1]+".before");
				} catch (Exception e1) {
					before="";
				}
				//�ļ�������ʽ Template_mybatis_xml_src.ftl
				//�����������»��� ���������»����� Template_mybatis_xml_src.ftl
				// Template���ļ����� �޹��   mybatis ���ڲ��Ҵ���ļ���·�� ���ҵĹ�����template.mybatis.path
				//xml�Ǵ���ļ��ĺ�׺ src��ָ�Ƿ�����src�� �ļ����·����template.mybatis.package
				//
				//��һ���»��ߵ��������ɱ���һ���ļ���ȥ ��Template_sql.ftl
				//���ڲ��Ҵ���ļ���·�� ���ҵĹ�����template.Template.path
				if (fileType.length==2) {//�������ɵ�һ���ļ���
					String targetFilePath=path;
					targetFilePath+="/src/"+ bundle.getString("template."+fileType[0]+".path").replaceAll("\\.", "/");
					File target = new File(targetFilePath); 
					if(!target.exists()){
						target.mkdirs();
					}
					target = new File(targetFilePath+"/"+fileType[0]+"."+fileType[1]);
					if((target.exists()&&rewirte)||!target.exists()){
						System.out.println("��ʼ�����ļ���"+targetFilePath+"/"+fileType[0]+"."+fileType[1]);
						Writer out = new OutputStreamWriter(new FileOutputStream(target), pageEncoding);  
						template.process(all, out);  
						out.flush();  
						out.close(); 
					}else{
						System.out.println("�ļ���"+targetFilePath+"/"+fileType[0]+"."+fileType[1]+"�Ѿ����ڣ������Ҫ��д������template.properties������template.rewriter=true��");
					}
				}else {
					String targetPath="";
					try {
						targetPath = bundle.getString("template."+fileType[1]+".path").replaceFirst("\\?",targetClazz.get("CLASSNAME").toString());
					} catch (RuntimeException e1) {
						targetPath="";
						System.out.println(e1.getMessage());
					}
					String targetFilePath=path;
					String p="";
					try {
						p = bundle.getString("template."+fileType[1]+".package");
						if(p==null||"".equals(p)){
							p=targetPath;
						}
					} catch (Exception e) {
						p=targetPath;
					}
					targetClazz.put("package",p );
					if("java".equals(fileType[2])||(fileType.length>3&&"src".equals(fileType[3]))){
						targetFilePath+="/src/"+ bundle.getString("template."+fileType[1]+".path").replaceAll("\\.", "/");
					}else if((fileType.length>3&&"webroot".equals(fileType[3]))){
						targetFilePath+="/WebRoot/"+ targetPath;
					}else{
						targetFilePath+="/"+ targetPath;
					}
					File target = new File(targetFilePath); 
					if(!target.exists()){
						target.mkdirs();
					}
					String newFileName=targetClazz.get("CLASSNAME")+"."+fileType[2];
					targetClazz.put("BEFORE", before);
					targetClazz.put("END", end);
					if ("true".equals(sign)){
						newFileName=before+targetClazz.get("CLASSNAME")+end+"."+fileType[2];
					}
					target = new File(targetFilePath+"/"+newFileName);
					if("js".equals(fileType[2])){
						targetClazz.put("JSPATH", "/"+targetPath+"/"+newFileName);
					}else if("xml".equals(fileType[2])){
						targetClazz.put("XMLPATH", "/"+targetPath.replaceAll("\\.", "/")+"/"+newFileName);
					}
					if((target.exists()&&rewirte)||!target.exists()){
						System.out.println("��ʼ�����ļ���"+targetFilePath+"/"+newFileName);
						Writer out = new OutputStreamWriter(new FileOutputStream(target), pageEncoding);  
						template.process(targetClazz, out);  
						out.flush();  
						out.close(); 
					}else{
						System.out.println("�ļ���"+targetFilePath+"/"+targetClazz.get("CLASSNAME")+"."+fileType[2]+"�Ѿ����ڣ������Ҫ��д������template.properties������template.rewriter=true��");
					}
				}
			}
		}
		//����xml·��
//		Template template =  con.getTemplate("XMLPATH_txt.ftl", pageEncoding);
//		Writer out = new OutputStreamWriter(new FileOutputStream(new File(path+"\\src\\XMLPATH.txt")), pageEncoding);  
//		template.process(all, out);  
//		out.flush();  
//		out.close();
		System.out.println("��ʼ�����ļ�������");
	}
	/**
	 * @return List<Map<String, Object>>
	 * key��˵��
	 * FK �����������
	 * PK ������������
	 * FIELDS �����еļ���
	 * NOPK �������������еļ���
	 * TABLENAME ��������
	 * CLASSNAME �����������
	 * TITLE ����ע��
	 * 
	 * @throws Exception
	 */
	public  List<Map<String, Object>> getTables() throws Exception{
		String tablename = this.request.getParameter("tablename");
		String tableSql = "select tableen classname,tablech title from tables ";
		DB db = new DB();
		List<Map<String, Object>> tableList = db.queryUpper(tableSql);
		System.out.println(tableSql);
		for(Map<String, Object> table:tableList){
			String table_name = table.get("CLASSNAME").toString();
			String colSql = " select col colname,datatype type,colname title,showtype,checktype,isreadonly,sqlid,style,event,other,changeid,changesqlid from cols where tablename='"+table_name+"' order by num ";
			List<Map<String, Object>> colList = db.queryUpper(colSql);
			List<Map<String, Object>> pkList = db.queryUpper("select tablename classname,col colname from cols where pk='1' and tablename='"+table_name+"' ");
			List<Map<String, Object>> fkList = db.queryUpper("select tablename classname,col colname from cols where fk='1' and tablename='"+table_name+"' ");
			//fk
			List<Map<String, Object>> nopkcolList=new ArrayList<Map<String,Object>>();
			Map<String, Object> fk = new HashMap<String, Object>();
			for(Map<String, Object> col:fkList){
				col.put("FK", Util.getCamleToLower(Util.getCamle(col.get("COLNAME").toString())));
				col.put("CLASSNAME", Util.getCamle(col.get("CLASSNAME").toString()));
				fk.put("FK", Util.getCamleToLower(Util.getCamle(col.get("COLNAME").toString())));
				fk.put("CLASSNAME", col.get("CLASSNAME").toString());
				fk.put(col.get("COLNAME").toString(), "sign");
			}
			for(Map<String, Object> col:colList){
				col.put("JDBCTYPE", col.get("TYPE"));
				col.put("TYPE", TypeRelation.get(col.get("TYPE")));
				//COLNAME
				col.put("JDBCCOLNAME",col.get("COLNAME"));
				col.put("COLNAMEPROPERTY", Util.getCamleToLower(Util.getCamle(col.get("COLNAME").toString())));
				col.put("COLNAME", Util.getCamle(col.get("COLNAME").toString()));
				if("sign".equals(fk.get(col.get("JDBCCOLNAME")))){
					col.put("CLASSNAME", fk.get("CLASSNAME"));
				}
				if (col.get("TITLE")==null) {
					col.put("TITLE", "");
				}
				//���û���������м���
				boolean  bo= true;
				for(Map<String, Object> pk:pkList){
					if (col.get("JDBCCOLNAME").toString().toLowerCase().equals(pk.get("COLNAME").toString().toLowerCase())) {
						bo=false;
						break;
					}
				}
				if (bo) {
					nopkcolList.add(col);
				}
			}
			table.put("TABLENAME", table.get("CLASSNAME").toString());
			table.put("CLASSNAME", Util.getCamle(table.get("CLASSNAME").toString()));
			table.put("FIELDS", colList);
			if (table.get("TITLE")==null) {
				table.put("TITLE", "");
			}
			//pk
			for(Map<String, Object> col:pkList){
				col.put("PK", Util.getCamleToLower(Util.getCamle(col.get("COLNAME").toString())));
				col.put("JDBCCOLNAME",col.get("COLNAME"));
			}
			table.put("PK", pkList);
			table.put("FK", fkList);
			table.put("NOPK", nopkcolList);
		}
		return tableList;
	}
	public static File[] sort(File[]templates){
		List<File> fileList = new ArrayList<File>();
		for (int i = 0; i < templates.length; i++) {
			fileList.add(templates[i]);
		}
		Collections.sort(fileList, new Comparator<File>() {
		    public int compare(File o1, File o2) {
		        if (o1.isDirectory() && o2.isFile())
		            return -1;
		        if (o1.isFile() && o2.isDirectory())
		            return 1;
		        return o1.getName().compareTo(o2.getName());
		    }
		});
		for (int i = 0; i < fileList.size(); i++) {
			templates[i]=fileList.get(i);
		}
		return templates;
	}
	
}
