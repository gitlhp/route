package com.freemaker;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.util.Util;



public class DB {
	public static String SQLTYPE=null;
	static{
		try {
			Class.forName(Util.getPropertyResourceBundleValue("jdbcc", "jdbc.driverClassName"));
			//�������ݿ�����
			SQLTYPE=(Util.getPropertyResourceBundleValue("jdbcc", "jdbc.sqltype"));
			if(SQLTYPE==null){
				SQLTYPE="sqlserver";
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	/**
	 * ��ȡ���ݿ�����
	 * @return
	 */
	public Connection getConnection(){
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(Util.getPropertyResourceBundleValue("jdbcc","jdbc.url"), 
					Util.getPropertyResourceBundleValue("jdbcc","jdbc.username"),
					Util.getPropertyResourceBundleValue("jdbcc", "jdbc.password"));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}
	/**
	 * ִ��SQL�����ɾ��
	 * @param sql
	 * @return
	 */
	public int executeSql(String sql){
		Connection connection = getConnection();
		Statement stmt= null;
		try {
			stmt= connection.createStatement();
			int res = stmt.executeUpdate(sql);
			return res;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			if (stmt!=null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(connection!=null){
				try {
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return -1;
	}
	public List<Map<String, Object>> query(String sql){
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		Connection connection = getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = connection.createStatement();
			rs=stmt.executeQuery(sql);
			ResultSetMetaData md = rs.getMetaData();
			int cc = md.getColumnCount();
			while (rs.next()) {
				Map<String, Object> map = new HashMap<String, Object>();
				for (int i = 1; i <= cc; i++) {
					String c =md.getColumnName(i);
					Object object = rs.getObject(c);
					if(object==null){
						object="";
					}
					map.put(c.toLowerCase(), object);
				}
				list.add(map);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				if (rs!=null) {
					rs.close();
				}
				if (stmt!=null) {
					stmt.close();
				}
				if (connection!=null) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	public List<List> queryList(String sql){
		List<List> list = new ArrayList<List>();
		Connection connection = getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = connection.createStatement();
			rs=stmt.executeQuery(sql);
			ResultSetMetaData md = rs.getMetaData();
			int cc = md.getColumnCount();
			while (rs.next()) {
				List list1 = new ArrayList();
				for (int i = 1; i <= cc; i++) {
					String c =md.getColumnName(i);
					Object object = rs.getObject(c);
					if(object==null){
						object="";
					}
					list1.add(object);
				}
				list.add(list1);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				if (rs!=null) {
					rs.close();
				}
				if (stmt!=null) {
					stmt.close();
				}
				if (connection!=null) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	public List<Map<String, Object>> queryUpper(String sql){
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		Connection connection = getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = connection.createStatement();
			rs=stmt.executeQuery(sql);
			ResultSetMetaData md = rs.getMetaData();
			int cc = md.getColumnCount();
			while (rs.next()) {
				Map<String, Object> map = new HashMap<String, Object>();
				for (int i = 1; i <= cc; i++) {
					String c =md.getColumnName(i);
					Object object = rs.getObject(c);
					if(object==null){
						object="";
					}
					map.put(c.toUpperCase(), object);
				}
				list.add(map);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				if (rs!=null) {
					rs.close();
				}
				if (stmt!=null) {
					stmt.close();
				}
				if (connection!=null) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	public String queryFirst(String sql){
		String res="";
		Connection connection = getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
			int cc = rs.getMetaData().getColumnCount();
			if (rs.next()) {
					Object object = rs.getObject(1);
					if(object!=null){
						res=object.toString();
					}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if(rs!=null)
					rs.close();
				if (stmt!=null)
					stmt.close();
				if(connection!=null)
					connection.close();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return res;
	}
	public int batchSql(String[] sqls){
		Connection con = null;
		Statement stmt = null;
		int res = 0;
		try {
			con =getConnection();
			con.setAutoCommit(false);
			stmt =con.createStatement();
			stmt.clearBatch();
			for(String sql:sqls){
				stmt.addBatch(sql);
			}
			int[]temp =stmt.executeBatch();
			for(int test:temp){
				if(test<0){
					res=-1;
					break;
				}
			}
			if(res>=0){
				res=temp.length;
			}
			con.commit();
			con.setAutoCommit(true);
		} catch (SQLException e) {
			res=-1;
			try {
			con.rollback();
			} catch (SQLException e1) {
			}
		}finally{
			try {
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
			} catch (SQLException e) {
			}
		}
		return res;
	}
	public static void main(String[] args) {
	}
}
