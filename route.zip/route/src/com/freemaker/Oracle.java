package com.freemaker;

public class Oracle implements DataBaseTypeRelation {
	static{
		TypeRelation.put("VARCHAR2", "java.lang.String");
		TypeRelation.put("CHAR", "java.lang.String");
		TypeRelation.put("NUMBER", "long");
		TypeRelation.put("DATE", "java.lang.String");
		TypeRelation.put("FLOAT", "float");
		TypeRelation.put("LONG", "long");
		TypeRelation.put("NVARCHAR2", "java.lang.String");
		TypeRelation.put("UROWID", "java.lang.String");
		TypeRelation.put("BLOB", "byte[]");
	}
	public String getCols(String tablename,String userName) {
		return "SELECT c.column_name colname,c.data_type type,s.comments title FROM user_col_comments s,USER_TAB_COLS c where c.table_name=s.table_name and s.column_name=c.column_name and  c.table_name='"+tablename+"'";
	}

	public String getTables(String userName) {
//		return "SELECT table_name FROM dba_tables where owner='"+userName+"'";
		return "SELECT t.table_name classname,s.comments title from user_tab_comments s,user_tables t where s.table_name=t.table_name and t.table_name like 'TBL_%'  ";
	}
	public String getPk(String tablename,String userName) {
		return " select cu.table_name classname,cu.column_name colname from user_cons_columns cu, user_constraints au "+ 
        "where cu.constraint_name = au.constraint_name and au.constraint_type = 'P' and au.table_name ='"+tablename+"'";
	}
	public String getFk(String tablename,String userName) {
		return " select cu.table_name classname,cu.column_name colname from user_cons_columns cu, user_constraints au "+ 
		"where cu.constraint_name = au.r_constraint_name and au.constraint_type = 'R' and au.table_name ='"+tablename+"'";
	}
	public static void main(String[] args) {
		DataBaseTypeRelation o = new Oracle() ;
		System.out.println(o.TypeRelation.get("VARCHAR2"));
	}
}
