package com.freemaker;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.ColsDao;
import com.util.Util;

public class OperAction  extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String method = request.getParameter("method");
		if("init".equals(method)){
			//��ʼ���������ñ�
			OperDao operDao = new OperDao();
			operDao.init();
			Util.printResult(response, "������ɣ�");
		}else if("create".equals(method)){
			Create create = new Create();
			create.init(request);
		}else if("addCols".equals(method)){
			ColsDao dao = new ColsDao();
			int res = dao.addCols(request);
			String msg="����ʧ�ܣ�";
			if(res>=0){
				msg="�����ɹ���";
			}
			request.setAttribute("Colsmsg",msg);
			request.getRequestDispatcher("/ColsList.jsp").forward(request, response);
		}
		else if("updCols".equals(method)){
			ColsDao dao = new ColsDao();
			int res = dao.updCols(request);
			String msg="����ʧ�ܣ�";
			if(res>=0){
				msg="�����ɹ���";
			}
			request.setAttribute("Colsmsg",msg);
			request.getRequestDispatcher("/ColsList.jsp").forward(request, response);
		}
		else if("delCols".equals(method)){
			ColsDao dao = new ColsDao();
			//request.setAttribute("delCols",dao.delCols(request));
			Util.printResult(response, dao.delCols(request)+"", "text/html;charset=gbk", true);
		}
		else if("findColsById".equals(method)){
			ColsDao dao = new ColsDao();
			request.setAttribute("findColsById",dao.findColsById(request));
			request.getRequestDispatcher("/Cols.jsp").forward(request, response);
		}
		else if("findColsByCondition".equals(method)){
			ColsDao dao = new ColsDao();
			request.setAttribute("findColsByCondition",dao.findColsByCondition(request));
			request.getRequestDispatcher("/ColsList.jsp").forward(request, response);
		}
	}
	
}
