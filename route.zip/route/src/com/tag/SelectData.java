
package com.tag;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

import com.dao.DB;

/**
 * ���������������ݱ�ǩ
 */
public class SelectData extends TagSupport {

	private static final long serialVersionUID = 2592840134309221367L;
	private String code;
	private String name;
	private String styleclass;
	private String id;
	private String change;
	private int    size;
	private int selsign;//0��ʾ����ѡ�񡱣�1Ϊ����ʾ��2Ϊ��ʾ��ȫ����
	private String style;
	private String def;//Ĭ��ֵ
	
	public SelectData() {

	}

	public int doEndTag() throws JspException {
		try {

			//------------------------
			//ȡ����������
			List list = new ArrayList();
			if(code!=null){
				//����ҵ������
				//list���ݼ���
				DB db = new DB();
				if(!"".equals(code)){
					String sql = db.queryFirst("select sqlcontent from sqls where sqlid='"+code+"'");
					if(sql!=null&&!"".equals(sql)){
						list = db.queryList(sql);
					}
				}
			 }
			HttpServletRequest request = (HttpServletRequest) this.pageContext.getRequest();
			String contPath = request.getContextPath();
			String result = "";
			result = "<select ";
			if (id != null) {
				result = result + " id=\"" + id + "\"";
			}
			if (size != 0) {
				result = result + " size=" + size + "";
			}
			if (styleclass != null) {
				result = result + " class=\"" + styleclass + "\"";
			}
			if (name != null) {
				result = result + " name=\"" + name + "\"";
			}
			if (change != null) {
				change = change.replaceAll("contPath", contPath);
				result = result + " onChange=\"" + change + "\"";
			}
			if (style != null) {
				result = result + " style=\"" + style + "\"";
			}
			result = result + ">";
			pageContext.getOut().write(result);
			if(selsign == 0){
				pageContext.getOut().write(
						"<option value=\'"

								+ "\'>"
								+ "--��ѡ��--"
								+ "</option>");
			} else if(selsign == 2){
				pageContext.getOut().write(
						"<option value=\'"

								+ "\'>"
								+ "--ȫ��--"
								+ "</option>");
			}
			
			if(list!=null){
			    Iterator iter = list.iterator();
			    while(iter.hasNext()){
			     List temp = (List)iter.next();
			     String sel="";
			     if(def!=null&&def.equals(temp.get(0).toString())){
			    	 sel="selected";
			     }
					pageContext.getOut().write(
							"<option value=\'"
									+ temp.get(0)
									+ "\' "+sel+">"
									+ temp.get(1)
									+ "</option>");
				}
			}
			
			pageContext.getOut().write("</select>");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return super.doEndTag();
	}

	public int doStartTag() throws JspException {
		// TODO Auto-generated method stub
		return super.doStartTag();
	}
	public String getStyle() {
		return style;
	}

	public void setStyle(String style) {
		this.style = style;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}
	public String getChange(){
		return change;
	}
	public void setChange(String change){
		this.change = change;
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSelsign() {
		return selsign;
	}

	public void setSelsign(int selsign) {
		this.selsign = selsign;
	}
	public String getcode() {
		return code;
	}

	public void setcode(String code) {
		this.code = code;
	}

	public String getStyleclass() {
		return styleclass;
	}

	public void setStyleclass(String styleclass) {
		this.styleclass = styleclass;
	}

	public String getDef() {
		return def;
	}

	public void setDef(String def) {
		this.def = def;
	}
	
}
