package com.action;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.CommonDao;
import com.dao.DB;
import com.util.*;
import com.dao.*;

public class CommonAction extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException {
		this.doPost(arg0, arg1);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String method = request.getParameter("method");
		if("".equals(method)){
		}
				else if("addSheet".equals(method)){
			SheetDao dao = new SheetDao();
			int res = dao.addSheet(request);
			String msg="����ʧ�ܣ�";
			if(res>=0){
				msg="�����ɹ���";
			}
			request.setAttribute("Sheetmsg",msg);
			request.getRequestDispatcher("/Sheet.jsp").forward(request, response);
		}
		else if("updSheet".equals(method)){
			SheetDao dao = new SheetDao();
			Util.printResult(response, dao.updSheet(request)+"", "text/html;charset=gbk", true);
		}
		else if("delSheet".equals(method)){
			SheetDao dao = new SheetDao();
			//request.setAttribute("delSheet",dao.delSheet(request));
			Util.printResult(response, dao.delSheet(request)+"", "text/html;charset=gbk", true);
		}
		else if("findSheetById".equals(method)){
			SheetDao dao = new SheetDao();
			request.setAttribute("findSheetById",dao.findSheetById(request));
			request.getRequestDispatcher("/Sheet.jsp").forward(request, response);
		}
		else if("findSheetByCondition".equals(method)){
			SheetDao dao = new SheetDao();
			request.setAttribute("findSheetByCondition",dao.findSheetByCondition(request));
			request.getRequestDispatcher("/SheetList.jsp").forward(request, response);
		}
		else if("addCar".equals(method)){
			CarDao dao = new CarDao();
			int res = dao.addCar(request);
			String msg="����ʧ�ܣ�";
			if(res>=0){
				msg="�����ɹ���";
			}
			request.setAttribute("Carmsg",msg);
			request.getRequestDispatcher("/CarList.jsp").forward(request, response);
		}
		else if("updCar".equals(method)){
			CarDao dao = new CarDao();
			int res = dao.updCar(request);
			String msg="����ʧ�ܣ�";
			if(res>=0){
				msg="�����ɹ���";
			}
			request.setAttribute("Carmsg",msg);
			request.getRequestDispatcher("/CarList.jsp").forward(request, response);
		}
		else if("delCar".equals(method)){
			CarDao dao = new CarDao();
			//request.setAttribute("delCar",dao.delCar(request));
			Util.printResult(response, dao.delCar(request)+"", "text/html;charset=gbk", true);
		}
		else if("findCarById".equals(method)){
			CarDao dao = new CarDao();
			request.setAttribute("findCarById",dao.findCarById(request));
			request.getRequestDispatcher("/Car.jsp").forward(request, response);
		}
		else if("findCarByCondition".equals(method)){
			CarDao dao = new CarDao();
			request.setAttribute("findCarByCondition",dao.findCarByCondition(request));
			request.getRequestDispatcher("/CarList.jsp").forward(request, response);
		}
		else if("addRange".equals(method)){
			RangeDao dao = new RangeDao();
			int res = dao.addRange(request);
			String msg="����ʧ�ܣ�";
			if(res>=0){
				msg="�����ɹ���";
			}
			request.setAttribute("Rangemsg",msg);
			request.getRequestDispatcher("/RangeList.jsp").forward(request, response);
		}
		else if("updRange".equals(method)){
			RangeDao dao = new RangeDao();
			int res = dao.updRange(request);
			String msg="����ʧ�ܣ�";
			if(res>=0){
				msg="�����ɹ���";
			}
			request.setAttribute("Rangemsg",msg);
			request.getRequestDispatcher("/RangeList.jsp").forward(request, response);
		}
		else if("delRange".equals(method)){
			RangeDao dao = new RangeDao();
			//request.setAttribute("delRange",dao.delRange(request));
			Util.printResult(response, dao.delRange(request)+"", "text/html;charset=gbk", true);
		}
		else if("findRangeById".equals(method)){
			RangeDao dao = new RangeDao();
			request.setAttribute("findRangeById",dao.findRangeById(request));
			request.getRequestDispatcher("/Range.jsp").forward(request, response);
		}
		else if("findRangeByCondition".equals(method)){
			RangeDao dao = new RangeDao();
			request.setAttribute("findRangeByCondition",dao.findRangeByCondition(request));
			request.getRequestDispatcher("/RangeList.jsp").forward(request, response);
		}
		else if("addPrice".equals(method)){
			PriceDao dao = new PriceDao();
			int res = dao.addPrice(request);
			String msg="����ʧ�ܣ�";
			if(res>=0){
				msg="�����ɹ���";
			}
			request.setAttribute("Pricemsg",msg);
			request.getRequestDispatcher("/PriceList.jsp").forward(request, response);
		}
		else if("updPrice".equals(method)){
			PriceDao dao = new PriceDao();
			int res = dao.updPrice(request);
			String msg="����ʧ�ܣ�";
			if(res>=0){
				msg="�����ɹ���";
			}
			request.setAttribute("Pricemsg",msg);
			request.getRequestDispatcher("/PriceList.jsp").forward(request, response);
		}
		else if("delPrice".equals(method)){
			PriceDao dao = new PriceDao();
			//request.setAttribute("delPrice",dao.delPrice(request));
			Util.printResult(response, dao.delPrice(request)+"", "text/html;charset=gbk", true);
		}
		else if("findPriceById".equals(method)){
			PriceDao dao = new PriceDao();
			request.setAttribute("findPriceById",dao.findPriceById(request));
			request.getRequestDispatcher("/Price.jsp").forward(request, response);
		}
		else if("findPriceByCondition".equals(method)){
			PriceDao dao = new PriceDao();
			request.setAttribute("findPriceByCondition",dao.findPriceByCondition(request));
			request.getRequestDispatcher("/PriceList.jsp").forward(request, response);
		}
		else if("addPoiint".equals(method)){
			PoiintDao dao = new PoiintDao();
			int res = dao.addPoiint(request);
			String msg="����ʧ�ܣ�";
			if(res>=0){
				msg="�����ɹ���";
			}
			request.setAttribute("Poiintmsg",msg);
			request.getRequestDispatcher("/PoiintList.jsp").forward(request, response);
		}
		else if("updPoiint".equals(method)){
			PoiintDao dao = new PoiintDao();
			int res = dao.updPoiint(request);
			String msg="����ʧ�ܣ�";
			if(res>=0){
				msg="�����ɹ���";
			}
			request.setAttribute("Poiintmsg",msg);
			request.getRequestDispatcher("/PoiintList.jsp").forward(request, response);
		}
		else if("delPoiint".equals(method)){
			PoiintDao dao = new PoiintDao();
			//request.setAttribute("delPoiint",dao.delPoiint(request));
			Util.printResult(response, dao.delPoiint(request)+"", "text/html;charset=gbk", true);
		}
		else if("findPoiintById".equals(method)){
			PoiintDao dao = new PoiintDao();
			request.setAttribute("findPoiintById",dao.findPoiintById(request));
			request.getRequestDispatcher("/Poiint.jsp").forward(request, response);
		}
		else if("findPoiintByCondition".equals(method)){
			PoiintDao dao = new PoiintDao();
			request.setAttribute("findPoiintByCondition",dao.findPoiintByCondition(request));
			request.getRequestDispatcher("/PoiintList.jsp").forward(request, response);
		}
		else if("addConfig".equals(method)){
			ConfigDao dao = new ConfigDao();
			int res = dao.addConfig(request);
			String msg="����ʧ�ܣ�";
			if(res>=0){
				msg="�����ɹ���";
			}
			request.setAttribute("Configmsg",msg);
			request.getRequestDispatcher("/ConfigList.jsp").forward(request, response);
		}
		else if("updConfig".equals(method)){
			ConfigDao dao = new ConfigDao();
			int res = dao.updConfig(request);
			String msg="����ʧ�ܣ�";
			if(res>=0){
				msg="�����ɹ���";
			}
			request.setAttribute("Configmsg",msg);
			request.getRequestDispatcher("/ConfigList.jsp").forward(request, response);
		}
		else if("delConfig".equals(method)){
			ConfigDao dao = new ConfigDao();
			//request.setAttribute("delConfig",dao.delConfig(request));
			Util.printResult(response, dao.delConfig(request)+"", "text/html;charset=gbk", true);
		}
		else if("findConfigById".equals(method)){
			ConfigDao dao = new ConfigDao();
			request.setAttribute("findConfigById",dao.findConfigById(request));
			request.getRequestDispatcher("/Config.jsp").forward(request, response);
		}
		else if("findConfigByCondition".equals(method)){
			ConfigDao dao = new ConfigDao();
			request.setAttribute("findConfigByCondition",dao.findConfigByCondition(request));
			request.getRequestDispatcher("/ConfigList.jsp").forward(request, response);
		}
		else if("addRoute".equals(method)){
			RouteDao dao = new RouteDao();
			int res = dao.addRoute(request);
			String msg="����ʧ�ܣ�";
			if(res>=0){
				msg="�����ɹ���";
			}
			request.setAttribute("Routemsg",msg);
			request.getRequestDispatcher("/RouteList.jsp").forward(request, response);
		}
		else if("updRoute".equals(method)){
			RouteDao dao = new RouteDao();
			int res = dao.updRoute(request);
			String msg="����ʧ�ܣ�";
			if(res>=0){
				msg="�����ɹ���";
			}
			request.setAttribute("Routemsg",msg);
			request.getRequestDispatcher("/RouteList.jsp").forward(request, response);
		}
		else if("delRoute".equals(method)){
			RouteDao dao = new RouteDao();
			//request.setAttribute("delRoute",dao.delRoute(request));
			Util.printResult(response, dao.delRoute(request)+"", "text/html;charset=gbk", true);
		}
		else if("findRouteById".equals(method)){
			RouteDao dao = new RouteDao();
			request.setAttribute("findRouteById",dao.findRouteById(request));
			request.getRequestDispatcher("/Route.jsp").forward(request, response);
		}
		else if("findRouteByCondition".equals(method)){
			RouteDao dao = new RouteDao();
			request.setAttribute("findRouteByCondition",dao.findRouteByCondition(request));
			request.getRequestDispatcher("/RouteList.jsp").forward(request, response);
		}
		else if("addRoutePoint".equals(method)){
			RoutePointDao dao = new RoutePointDao();
			int res = dao.addRoutePoint(request);
			String msg="����ʧ�ܣ�";
			if(res>=0){
				msg="�����ɹ���";
			}
			request.setAttribute("RoutePointmsg",msg);
			request.getRequestDispatcher("/RoutePointList.jsp").forward(request, response);
		}
		else if("updRoutePoint".equals(method)){
			RoutePointDao dao = new RoutePointDao();
			int res = dao.updRoutePoint(request);
			String msg="����ʧ�ܣ�";
			if(res>=0){
				msg="�����ɹ���";
			}
			msg="<script>alert('"+msg+"');self.close();</script>";
			request.setAttribute("js",msg);
			request.getRequestDispatcher("/js.jsp").forward(request, response);
		}
		else if("delRoutePoint".equals(method)){
			RoutePointDao dao = new RoutePointDao();
			//request.setAttribute("delRoutePoint",dao.delRoutePoint(request));
			Util.printResult(response, dao.delRoutePoint(request)+"", "text/html;charset=gbk", true);
		}
		else if("findRoutePointById".equals(method)){
			RoutePointDao dao = new RoutePointDao();
			request.setAttribute("findRoutePointById",dao.findRoutePointById(request));
			request.getRequestDispatcher("/RoutePoint.jsp").forward(request, response);
		}
		else if("findRoutePointByCondition".equals(method)){
			RoutePointDao dao = new RoutePointDao();
			request.setAttribute("findRoutePointByCondition",dao.findRoutePointByCondition(request));
			request.getRequestDispatcher("/RoutePointList.jsp").forward(request, response);
		}
		
	}
	
}


