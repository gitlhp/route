package com.action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.DB;
import com.dao.NotieDao;
import com.util.Util;

public class UtilAction  extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String method = request.getParameter("method");
		if("changeselect".equals(method)){
			int i = 0;
			String temp = null;
			List list = new ArrayList();
			while ((temp = request.getParameter("param" + i))!=null){
				String val=temp;
				if(Util.isMessyCode(temp)){
					val = Util.ISOtoUTF8(temp);
					if(Util.isMessyCode(val)){
						val = Util.ISOtoGb2312(temp);
					}
				}
				list.add(val);
				i++;
			}
			String sqlid = request.getParameter("sqlid");
			DB db = new DB();
			String sql =db.queryFirst("select sqlcontent from sqls where sqlid='"+sqlid+"'");
			String res="[]";
			if(sql!=null&&!"".equals(sql)){
				List<List> reslist = db.queryList(sql, list.toArray());
				res=Util.parseListToJson(reslist);
			}
			Util.printResult(response, res);
		}else if("addNotie".equals(method)){
			NotieDao dao = new NotieDao();
			int res = dao.addNotie(request);
			String msg="����ʧ�ܣ�";
			if(res>=0){
				msg="�����ɹ���";
			}
			request.setAttribute("Notiemsg",msg);
			request.getRequestDispatcher("/NotieList.jsp").forward(request, response);
		}
		else if("updNotie".equals(method)){
			NotieDao dao = new NotieDao();
			int res = dao.updNotie(request);
			String msg="����ʧ�ܣ�";
			if(res>=0){
				msg="�����ɹ���";
			}
			request.setAttribute("Notiemsg",msg);
			request.getRequestDispatcher("/NotieList.jsp").forward(request, response);
		}
		else if("delNotie".equals(method)){
			NotieDao dao = new NotieDao();
			//request.setAttribute("delNotie",dao.delNotie(request));
			Util.printResult(response, dao.delNotie(request)+"", "text/html;charset=gbk", true);
		}
		else if("findNotieById".equals(method)){
			NotieDao dao = new NotieDao();
			request.setAttribute("findNotieById",dao.findNotieById(request));
			request.getRequestDispatcher("/Notie.jsp").forward(request, response);
		}
		else if("findNotieByCondition".equals(method)){
			NotieDao dao = new NotieDao();
			request.setAttribute("findNotieByCondition",dao.findNotieByCondition(request));
			request.getRequestDispatcher("/NotieList.jsp").forward(request, response);
		}
	}
	
}
