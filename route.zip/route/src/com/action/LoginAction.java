package com.action;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.CommonDao;
import com.dao.DB;
import com.util.ImagerHelp;
import com.util.Util;

public class LoginAction extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException {
		this.doPost(arg0, arg1);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String method = request.getParameter("method");
		//��ȡ��֤��
		if("getImg".equals(method)){
			try {
				ImagerHelp.createImage( response,request, 60, 30, 4);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return ;
		}
		//��֤��֤��
		else if("checkCode".equals(method)){
			HttpSession session = request.getSession();
			try{
				String checkcode = (String) session.getAttribute("code");
				String code = request.getParameter("code");
				String res = "";
				if(!code.equals(checkcode)){
					res=("{\"return_code\":\"error\"}");
				}else{
					res=("{\"return_code\":\"ok\"}");
				}
				Util.printResult(response, res, "text/html;charset=gbk", true);
			}catch(Exception e){
			}finally{
				response.getWriter().flush();
				response.getWriter().close();
			}
			return ;
		}
		//����û�������
		else if("login".equals(method)){
			String userId = request.getParameter("userId");
			String passWord = request.getParameter("passWord");
			String sql = "select * from users where userId='"+userId+"' and password='"+passWord+"'";
			DB db = new DB();
			List<Map<String,Object>> res = db.query(sql);
			String content = "";
			if(res==null||res.size()==0){
				content=("{\"return_code\":\"error\"}");
			}else{
				request.getSession().setAttribute("user", res.get(0));
				content=("{\"return_code\":\"ok\"}");
			}
			Util.printResult(response, content, "text/html;charset=gbk", true);
			//request.getRequestDispatcher("/index.jsp").forward(request, response);
			return ;
		}else if("checkusername".equals(method)){
			String userId = request.getParameter("userid");
			String sql = "select count(1) from users where userId='"+userId+"'";
			DB db = new DB();
			String res = db.queryFirst(sql);
			Util.printResult(response, res, "text/html;charset=gbk", true);
		}
	}
	
}
