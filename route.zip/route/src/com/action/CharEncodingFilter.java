package com.action;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class CharEncodingFilter implements Filter { 

	private String charSet ; 

	public void init(FilterConfig parm1) throws ServletException { 
		charSet = parm1.getInitParameter("charset") ; 
		if (charSet == null && charSet.length() < 1) 
		{ 
			charSet = "UTF-8" ; 
		} 
		System.out.println ("CharEncodingFilter--�ַ���: " + this.getCharSet()) ; 
	} 


	public void doFilter(ServletRequest parm1, ServletResponse parm2, 
			FilterChain parm3) throws IOException, ServletException { 

//		�趨�ַ��� 
		parm1.setCharacterEncoding(this.getCharSet()); 
		parm3.doFilter(parm1, parm2); 
//		ҳ����ÿ��������������󶼱����� -- �� ͼƬ,js,HTML/JSP�ȵ� 
//		System.out.println ("---CharEncodingFilter: " + this.getCharSet()) ; 
	} 

	public void destroy() { 
//		TODO: Add your code here 
		this.setCharSet(null) ; 
	} 


	public void setCharSet(String charSet) { 
		this.charSet = charSet; 
	} 

	public String getCharSet() { 
		return (this.charSet); 
	} 
}
