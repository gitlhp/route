package com.action;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.CommonDao;
import com.dao.DB;
import com.util.*;
import com.dao.*;

public class UserAction extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException {
		this.doPost(arg0, arg1);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String method = request.getParameter("method");
		if("".equals(method)){
		}
		else if("addCodes".equals(method)){
			CodesDao dao = new CodesDao();
			int res = dao.addCodes(request);
			String msg="����ʧ�ܣ�";
			if(res>=0){
				msg="�����ɹ���";
			}
			request.setAttribute("Codesmsg",msg);
			request.getRequestDispatcher("/CodesList.jsp").forward(request, response);
		}
		else if("updCodes".equals(method)){
			CodesDao dao = new CodesDao();
			int res = dao.updCodes(request);
			String msg="����ʧ�ܣ�";
			if(res>=0){
				msg="�����ɹ���";
			}
			request.setAttribute("Codesmsg",msg);
			request.getRequestDispatcher("/CodesList.jsp").forward(request, response);
		}
		else if("delCodes".equals(method)){
			CodesDao dao = new CodesDao();
			//request.setAttribute("delCodes",dao.delCodes(request));
			Util.printResult(response, dao.delCodes(request)+"", "text/html;charset=gbk", true);
		}
		else if("findCodesById".equals(method)){
			CodesDao dao = new CodesDao();
			request.setAttribute("findCodesById",dao.findCodesById(request));
			request.getRequestDispatcher("/Codes.jsp").forward(request, response);
		}
		else if("findCodesByCondition".equals(method)){
			CodesDao dao = new CodesDao();
			request.setAttribute("findCodesByCondition",dao.findCodesByCondition(request));
			request.getRequestDispatcher("/CodesList.jsp").forward(request, response);
		}
		else if("addUsers".equals(method)){
			UsersDao dao = new UsersDao();
			int res = dao.addUsers(request);
			String msg="����ʧ�ܣ�";
			if(res>=0){
				msg="�����ɹ���";
			}
			request.setAttribute("Usersmsg",msg);
			if("sign".equals(request.getParameter("sign"))){
				msg="ע��ʧ�ܣ�";
				if(res>=0){
					msg="ע��ɹ������½��";
				}
				request.setAttribute("Usersmsg",msg);
				request.getRequestDispatcher("/login.jsp").forward(request, response);
			}else{
				request.getRequestDispatcher("/UsersList.jsp").forward(request, response);
			}
			
		}
		else if("updUsers".equals(method)){
			UsersDao dao = new UsersDao();
			int res = dao.updUsers(request);
			String msg="����ʧ�ܣ�";
			if(res>=0){
				msg="�����ɹ���";
			}
			request.setAttribute("Usersmsg",msg);
			if("sign".equals(request.getParameter("sign"))){
				request.getRequestDispatcher("/userAction.do?method=findUsersById&userid="+request.getParameter("userid")).forward(request, response);
			}else
				request.getRequestDispatcher("/UsersList.jsp").forward(request, response);
		}
		else if("delUsers".equals(method)){
			UsersDao dao = new UsersDao();
			//request.setAttribute("delUsers",dao.delUsers(request));
			Util.printResult(response, dao.delUsers(request)+"", "text/html;charset=gbk", true);
		}
		else if("findUsersById".equals(method)){
			UsersDao dao = new UsersDao();
			request.setAttribute("findUsersById",dao.findUsersById(request));
			request.getRequestDispatcher("/Users.jsp").forward(request, response);
		}
		else if("findUsersByCondition".equals(method)){
			UsersDao dao = new UsersDao();
			request.setAttribute("findUsersByCondition",dao.findUsersByCondition(request));
			request.getRequestDispatcher("/UsersList.jsp").forward(request, response);
		}
		
	}
	
}


